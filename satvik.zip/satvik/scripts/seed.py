import csv
import sys
from pathlib import Path
import argparse

sys.path.append(str(Path(__file__).resolve().parent.parent))

from app.db.session import SessionLocal, engine
from app.db.models import user, role, permission, product
from app.db.models.role import Role
from app.db.models.permission import Permission
from app.db.models.product import Product
from app.db.models.user import User
from sqlalchemy.exc import OperationalError, ProgrammingError
from sqlalchemy import text

# --- Comprehensive Data Definitions ---
DEFAULT_PERMISSIONS = {
    "product:create": "Allows creating new products",
    "product:read": "Allows reading product information",
    "product:update": "Allows updating existing products",
    "product:delete": "Allows deleting products",
    "admin:read:users": "Allows viewing the list of all users",
    "admin:update:users": "Allows editing user details",
    "admin:assign:roles": "Allows assigning/un-assigning roles to users",
    "admin:read:roles": "Allows viewing roles and their permissions",
    "admin:create:role": "Allows creating new custom roles",
    "admin:update:role": "Allows editing existing roles",
    "admin:delete:role": "Allows deleting custom roles",
    "forecast:read": "Allows viewing demand forecast data",
    "optimization:read": "Allows viewing price optimization data"
}

DEFAULT_ROLES = {
    "admin": {
        "description": "Administrator with full system access",
        "permissions": list(DEFAULT_PERMISSIONS.keys())
    },
    "supplier": {
        "description": "Can manage products and view analytics",
        "permissions": ["product:create", "product:read", "product:update", "forecast:read", "optimization:read"]
    },
    "buyer": {
        "description": "Can only view products",
        "permissions": ["product:read"]
    }
}

def migrate_add_default_role_column():
    """Adds the default_role column to the roles table if it doesn't exist."""
    db = SessionLocal()
    print("Running migration: Add default_role column to roles table...")
    try:
        # Check if the column already exists
        db.execute(text("SELECT default_role FROM roles LIMIT 1"))
        print("Column 'default_role' already exists. Skipping.")
    except (OperationalError, ProgrammingError) as e:
        # If the column doesn't exist, an error will be raised.
        # We need to catch this and add the column.
        if "does not exist" in str(e):
            print("Column 'default_role' not found. Adding it now...")
            db.rollback() # Rollback the failing transaction
            db.execute(text("ALTER TABLE roles ADD COLUMN default_role BOOLEAN NOT NULL DEFAULT FALSE"))
            db.commit()
            print("Successfully added 'default_role' column.")
        else:
            # Re-raise other errors
            raise e
    except Exception as e:
        print(f"An unexpected error occurred during migration: {e}")
        db.rollback()
    finally:
        db.close()


def verify_user_email(email: str):
    """Sets a user's is_verified flag to True."""
    db = SessionLocal()
    print(f"Attempting to verify email for user '{email}'...")
    try:
        target_user = db.query(User).filter(User.email == email).first()
        if not target_user:
            print(f"Error: User with email '{email}' not found.")
            return

        if target_user.is_verified:
            print(f"User '{email}' is already verified.")
            return

        target_user.is_verified = True
        db.commit()
        print(f"Successfully verified email for '{email}'.")

    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        db.rollback()
    finally:
        db.close()


def set_default_roles_to_true():
    """Sets the default_role flag to True for the three default roles."""
    db = SessionLocal()
    print("Setting default roles (admin, supplier, buyer) to True...")
    try:
        default_role_names = ["admin", "supplier", "buyer"]
        roles_to_update = db.query(Role).filter(Role.name.in_(default_role_names)).all()

        if not roles_to_update:
            print("Default roles not found. Please seed the database first.")
            return

        for role in roles_to_update:
            role.default_role = True
        
        db.commit()
        print("Successfully updated default roles.")

    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        db.rollback()
    finally:
        db.close()


def create_all_tables():
    print("Creating all database tables...")
    try:
        user.Base.metadata.create_all(bind=engine)
        print("Tables created successfully.")
    except Exception as e:
        print(f"An error occurred during table creation: {e}")

def seed_roles_and_permissions():
    db = SessionLocal()
    print("Seeding roles and permissions...")
    try:
        # Create all Permissions
        for name, desc in DEFAULT_PERMISSIONS.items():
            db_permission = db.query(Permission).filter(Permission.name == name).first()
            if not db_permission:
                db_permission = Permission(name=name, description=desc)
                db.add(db_permission)
        db.commit()

        # Create all Roles and assign Permissions
        for name, role_data in DEFAULT_ROLES.items():
            db_role = db.query(Role).filter(Role.name == name).first()
            if not db_role:
                db_role = Role(name=name, description=role_data["description"])
                db.add(db_role)
            
            for perm_name in role_data["permissions"]:
                db_permission = db.query(Permission).filter(Permission.name == perm_name).first()
                if db_permission and db_permission not in db_role.permissions:
                    db_role.permissions.append(db_permission)
        
        db.commit()
        print("Successfully seeded roles and permissions.")
    except Exception as e:
        print(f"An error occurred during role/permission seeding: {e}")
        db.rollback()
    finally:
        db.close()

def seed_products():
    db = SessionLocal()
    print("Seeding product data...")
    try:
        if db.query(Product).count() > 0:
            print("Product data already exists. Skipping.")
            return

        csv_file_path = Path(__file__).resolve().parent.parent / "product_data.csv"
        with open(csv_file_path, mode='r', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                db.add(Product(**row))
        
        db.commit()
        print("Successfully seeded the database with product data.")
    except Exception as e:
        print(f"An error occurred during product seeding: {e}")
        db.rollback()
    finally:
        db.close()

# --- NEW, GENERALIZED FUNCTION TO ASSIGN ANY ROLE ---
def assign_role_to_user(email: str, role_name: str):
    """Assigns a specific role to a specific user."""
    db = SessionLocal()
    print(f"Attempting to assign '{role_name}' role to user '{email}'...")
    try:
        # Find the user by email
        target_user = db.query(User).filter(User.email == email).first()
        if not target_user:
            print(f"Error: User with email '{email}' not found.")
            return

        # Find the role by name
        target_role = db.query(Role).filter(Role.name == role_name).first()
        if not target_role:
            print(f"Error: Role '{role_name}' not found. Available roles: {list(DEFAULT_ROLES.keys())}")
            return
        
        # Check if the user already has the role
        if target_role in target_user.roles:
            print(f"User '{email}' already has the '{role_name}' role.")
            return

        # Assign the role
        target_user.roles.append(target_role)
        db.commit()
        print(f"Successfully assigned '{role_name}' role to '{email}'.")

    except Exception as e:
        print(f"An error occurred while assigning role: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Database Seeding and Management Script')
    parser.add_argument('--reset-db', action='store_true', help='Drop all tables, recreate, and seed all data.')
    parser.add_argument('--migrate', action='store_true', help='Run database migrations, like adding new columns.')
    parser.add_argument('--set-defaults', action='store_true', help='Set the default_role flag to True for default roles.')
    parser.add_argument('--verify-email', type=str, metavar='EMAIL', help='Verify a user\'s email address.')
    # --- NEW, MORE FLEXIBLE COMMAND-LINE ARGUMENT ---
    parser.add_argument('--assign-role', nargs=2, metavar=('EMAIL', 'ROLE_NAME'), 
                        help='Assign a role to a user. E.g., --assign-role user@example.com admin')
    
    args = parser.parse_args()

    if args.reset_db:
        print("Resetting database: Dropping all tables...")
        user.Base.metadata.drop_all(bind=engine)
        print("All tables dropped.")
        create_all_tables()
        seed_roles_and_permissions()
        seed_products()
        print("\nDatabase reset and seeded successfully.")
    elif args.migrate:
        migrate_add_default_role_column()
    elif args.set_defaults:
        set_default_roles_to_true()
    elif args.verify_email:
        verify_user_email(email=args.verify_email)
    # --- NEW LOGIC TO HANDLE THE ARGUMENT ---
    elif args.assign_role:
        email, role_name = args.assign_role
        assign_role_to_user(email=email, role_name=role_name)
    else:
        parser.print_help()