# app/main.py
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware # Import the middleware
from app.api.routers import products, auth, admin 
from app.db.session import engine, Base
# Import all models to ensure they are registered with SQLAlchemy
from app.db.models import product, user, role, permission

# Create all tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Price Optimization Tool API",
    description="API for managing products and running price optimization.",
    version="1.0.0"
)

origins = [
    "http://localhost:3000", 
    "http://localhost:3001", 
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,       # The origins that are allowed to make requests
    allow_credentials=True,      # Allow cookies to be included in requests
    allow_methods=["*"],         # Allow all methods (GET, POST, PUT, DELETE, etc.)
    allow_headers=["*"],         # Allow all headers
)

# --- Routers ---
app.include_router(auth.router, prefix="/api/v1/auth", tags=["Authentication"])
app.include_router(products.router, prefix="/api/v1/products", tags=["Products"])
app.include_router(admin.router, prefix="/api/v1/admin", tags=["Admin"])

@app.get("/", tags=["Root"])
def read_root():
    return {"message": "Welcome to the Price Optimization Tool API!"}