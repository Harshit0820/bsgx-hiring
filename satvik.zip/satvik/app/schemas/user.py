# app/schemas/user.py
from pydantic import BaseModel, EmailStr
from typing import List
from .role import Role, RoleWithPermissions

class UserBase(BaseModel):
    email: EmailStr
    full_name: str

class UserCreate(UserBase):
    password: str

class User(UserBase):
    id: int
    is_active: bool
    is_verified: bool

    class Config:
        from_attributes = True

class UserWithRoles(User): 
    roles: List[RoleWithPermissions] = []