# app/schemas/role.py
from pydantic import BaseModel
from typing import List
from .permission import Permission # Import the Permission schema

class RoleBase(BaseModel):
    name: str
    description: str | None = None
    default_role: bool = False

class RoleCreate(RoleBase):
    permission_ids: List[int] = [] # For creating a role with permissions

class Role(RoleBase):
    id: int

    class Config:
        from_attributes = True

class RoleWithPermissions(Role):
    permissions: List[Permission] = []