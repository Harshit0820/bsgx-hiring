# app/schemas/token.py
from pydantic import BaseModel
from typing import Optional

class Token(BaseModel):
    """
    This schema defines the structure of the JSON object that will be
    returned to the user upon a successful login.
    """
    access_token: str
    token_type: str

class TokenData(BaseModel):
    """
    This schema defines the data that is encoded inside the JWT.
    We are encoding the user's email in the 'sub' (subject) claim.
    """
    email: Optional[str] = None