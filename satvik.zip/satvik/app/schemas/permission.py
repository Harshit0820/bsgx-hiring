# app/schemas/permission.py
from pydantic import BaseModel

class Permission(BaseModel):
    id: int
    name: str
    description: str | None = None

    class Config:
        from_attributes = True