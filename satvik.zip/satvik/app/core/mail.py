# app/core/mail.py
import smtplib
import asyncio
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

from pydantic import EmailStr
from app.core.config import settings

def _send_email_sync(receiver_email: str, message: MIMEMultipart):
    """
    A private synchronous function to be run in a separate thread.
    This contains the core smtplib logic.
    """
    try:
        # Connect to the Mailtrap SMTP server using settings from .env
        with smtplib.SMTP(settings.MAILTRAP_SMTP_HOST, settings.MAILTRAP_SMTP_PORT) as server:
            server.starttls()  # Secure the connection
            # Login using 'api' as username and your API key as password
            server.login("api", settings.MAILTRAP_API_KEY)
            # Send the complete message
            server.sendmail(settings.MAIL_FROM_EMAIL, receiver_email, message.as_string())
        
        print(f"Verification email sent successfully to {receiver_email}")

    except Exception as e:
        print(f"Failed to send email to {receiver_email}. Error: {e}")
        # Propagate the error so the caller knows the email failed
        raise e

async def send_verification_email(email: EmailStr, token: str):
    """
    Constructs a multipart/alternative email and sends it via Mailtrap SMTP.
    This is the public async function called by the API router.
    """
    verification_link = f"{settings.FRONTEND_URL}/verify-email?token={token}"
    
    # Set the sender and receiver addresses
    sender_email = f"{settings.MAIL_FROM_NAME} <{settings.MAIL_FROM_EMAIL}>"
    receiver_email = email

    # Create the root message and set the headers.
    # 'alternative' means the client will choose the best version (HTML over plain text).
    message = MIMEMultipart("alternative")
    message["Subject"] = "Price Optimization Tool: Verify Your Email Address"
    message["From"] = sender_email
    message["To"] = receiver_email

    # --- Create the two versions of the message, as seen in the curl command ---

    # 1. The plain-text version.
    plain_text = f"""
    Thank you for registering.
    Please copy and paste the following link into your browser to verify your email address:
    {verification_link}
    
    This link will expire in 1 hour.
    """

    # 2. The HTML version.
    html_body = f"""
    <html>
      <head></head>
      <body style="font-family: sans-serif;">
        <div style="display: block; margin: auto; max-width: 600px;">
          <h1 style="font-size: 18px; font-weight: bold; margin-top: 20px;">Thank you for registering!</h1>
          <p>Please click the button below to verify your email address and activate your account.</p>
          <a href="{verification_link}" target="_blank" style="display: inline-block; padding: 12px 24px; font-size: 16px; color: #fff; background-color: #28a745; border-radius: 5px; text-decoration: none;">Verify Your Email</a>
          <p style="margin-top: 20px; font-size: 12px;">If you cannot click the button, please copy and paste this link into your browser:<br>{verification_link}</p>
          <p style="font-size: 12px;">This link will expire in 1 hour.</p>
        </div>
      </body>
    </html>
    """

    # Attach both parts to the message.
    # The email client will try to render the last part first (HTML).
    message.attach(MIMEText(plain_text, "plain"))
    message.attach(MIMEText(html_body, "html"))
    
    # Run the blocking smtplib code in a separate thread to avoid freezing the app
    await asyncio.to_thread(_send_email_sync, email, message)