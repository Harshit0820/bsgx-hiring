# app/core/config.py
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    # Database configuration
    DATABASE_URL: str

    # JWT settings
    SECRET_KEY: str
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30

    # Frontend URL for email verification link
    FRONTEND_URL: str = "http://localhost:3000"

    # --- UPDATED SMTP SETTINGS ---
    MAILTRAP_SMTP_HOST: str
    MAILTRAP_SMTP_PORT: int
    MAILTRAP_API_KEY: str
    MAIL_FROM_EMAIL: str
    MAIL_FROM_NAME: str

    class Config:
        env_file = ".env"

settings = Settings()