from fastapi import APIRouter, Depends, HTTPException, Body
from sqlalchemy.orm import Session
from typing import List

from app.db.session import get_db
from app.core.security import require_permission
from app.schemas.user import UserWithRoles
from app.schemas.role import RoleWithPermissions, Role as RoleSchema, Permission as PermissionSchema, RoleCreate
from app.db.crud import user as user_crud, role as role_crud

router = APIRouter()

# --- User Management ---
@router.get("/users", response_model=List[UserWithRoles])
def get_all_users(db: Session = Depends(get_db), current_user = Depends(require_permission("admin:read:users"))):
    return user_crud.get_users(db)

@router.post("/users/{user_id}/roles", response_model=UserWithRoles)
def assign_role_to_user(
    user_id: int,
    role_id: int = Body(..., embed=True),
    db: Session = Depends(get_db),
    current_user = Depends(require_permission("admin:assign:roles"))
):
    user = user_crud.get_user_by_id(db, user_id=user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    role = role_crud.get_role_by_id(db, role_id=role_id)
    if not role:
        raise HTTPException(status_code=404, detail="Role not found")
        
    # In this simple model, we replace the role. For multi-role systems, you'd append.
    user.roles = [role]
    db.commit()
    db.refresh(user)
    return user

@router.delete("/users/{user_id}/roles/{role_id}", response_model=UserWithRoles)
def revoke_role_from_user(
    user_id: int,
    role_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(require_permission("admin:assign:roles"))
):
    user = user_crud.get_user_by_id(db, user_id=user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    role = role_crud.get_role_by_id(db, role_id=role_id)
    if not role:
        raise HTTPException(status_code=404, detail="Role not found")
        
    if role in user.roles:
        user.roles.remove(role)
        db.commit()
        db.refresh(user)
        
    return user

# --- Role & Permission Management ---
@router.get("/roles", response_model=List[RoleWithPermissions])
def get_all_roles(db: Session = Depends(get_db), current_user = Depends(require_permission("admin:read:roles"))):
    return role_crud.get_roles(db)

@router.get("/permissions", response_model=List[PermissionSchema])
def get_all_permissions(db: Session = Depends(get_db), current_user = Depends(require_permission("admin:read:roles"))):
    return role_crud.get_permissions(db)

@router.post("/roles", response_model=RoleSchema)
def create_new_role(
    role_data: RoleCreate,
    db: Session = Depends(get_db),
    current_user = Depends(require_permission("admin:create:role"))
):
    existing_role = role_crud.get_role_by_name(db, role_name=role_data.name)
    if existing_role:
        raise HTTPException(status_code=400, detail="Role with this name already exists")
    return role_crud.create_role(db, name=role_data.name, description=role_data.description, permission_ids=role_data.permission_ids)

@router.put("/roles/{role_id}", response_model=RoleWithPermissions)
def update_existing_role(
    role_id: int,
    role_data: RoleCreate,
    db: Session = Depends(get_db),
    current_user = Depends(require_permission("admin:update:role"))
):
    role = role_crud.get_role_by_id(db, role_id=role_id)
    if not role:
        raise HTTPException(status_code=404, detail="Role not found")
    return role_crud.update_role(db, role=role, name=role_data.name, description=role_data.description, permission_ids=role_data.permission_ids)

@router.delete("/roles/{role_id}", status_code=204)
def delete_existing_role(
    role_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(require_permission("admin:delete:role"))
):
    role_to_delete = role_crud.get_role_by_id(db, role_id=role_id)
    if not role_to_delete:
        raise HTTPException(status_code=404, detail="Role not found")
    
    if role_to_delete.default_role:
        raise HTTPException(status_code=403, detail="Default roles cannot be deleted.")
        
    if role_to_delete.users:
        raise HTTPException(status_code=400, detail="Cannot delete a role that is currently assigned to users.")
        
    role_crud.delete_role(db, role=role_to_delete)
    return