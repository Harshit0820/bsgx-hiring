# app/api/routers/products.py
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional

from app.db.session import get_db
from app.db.crud import product as crud
from app.schemas.product import Product, ProductCreate, ProductWithOptimizedPrice
from app.core.security import require_permission # Import our security dependency
from app.db.models.user import User # Import the User model for type hinting

router = APIRouter()

@router.get("/", response_model=List[Product])
def read_products(
    db: Session = Depends(get_db),
    skip: int = 0,
    limit: int = 100,
    category: Optional[str] = Query(None, description="Filter products by category"),
    search: Optional[str] = Query(None, description="Search for products by name"),
    # Add dependency: User must have 'product:read' permission to view products
    current_user: User = Depends(require_permission("product:read"))
):
    """
    Retrieve all products. This endpoint is now protected and requires login
    and the 'product:read' permission.
    """
    products = crud.get_products(db, skip=skip, limit=limit, category=category, search=search)
    return products

@router.get("/optimize", response_model=List[ProductWithOptimizedPrice])
def get_optimized_product_prices(
    db: Session = Depends(get_db),
    category: Optional[str] = Query(None, description="Filter products by category"),
    search: Optional[str] = Query(None, description="Search for products by name"),
    current_user: User = Depends(require_permission("optimization:read"))
):
    """
    Retrieve all products with an additional calculated 'optimized_price' field.
    Protected by 'optimization:read' permission.
    """
    return crud.get_optimized_prices(db, category=category, search=search)

@router.get("/categories", response_model=List[str])
def get_unique_categories(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_permission("product:read"))
):
    """Retrieve a list of unique product categories."""
    return crud.get_unique_product_categories(db)

@router.post("/", response_model=Product, status_code=status.HTTP_201_CREATED)
def create_new_product(
    product: ProductCreate, 
    db: Session = Depends(get_db),
    # Add dependency: User must have 'product:create' permission
    current_user: User = Depends(require_permission("product:create"))
):
    """
    Create a new product. This endpoint is now protected and requires the
    'product:create' permission.
    """
    return crud.create_product(db=db, product=product)

@router.get("/{product_id}", response_model=Product)
def read_product(
    product_id: int, 
    db: Session = Depends(get_db),
    # Add dependency: User must have 'product:read' permission
    current_user: User = Depends(require_permission("product:read"))
):
    """
    Retrieve a single product by its ID. Protected by 'product:read' permission.
    """
    db_product = crud.get_product(db, product_id=product_id)
    if db_product is None:
        raise HTTPException(status_code=404, detail="Product not found")
    return db_product

@router.get("/{product_id}/forecast", response_model=List[dict])
def get_demand_forecast(
    product_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_permission("forecast:read"))
):
    """
    Retrieve a simulated demand forecast for a specific product.
    Protected by 'forecast:read' permission.
    """
    forecast_data = crud.get_demand_forecast_for_product(db, product_id=product_id)
    if not forecast_data:
        raise HTTPException(status_code=404, detail="Product not found or forecast could not be generated.")
    return forecast_data

@router.put("/{product_id}", response_model=Product)
def update_existing_product(
    product_id: int, 
    product_update: ProductCreate, 
    db: Session = Depends(get_db),
    # Add dependency: User must have 'product:update' permission
    current_user: User = Depends(require_permission("product:update"))
):
    """
    Update an existing product. Protected by 'product:update' permission.
    """
    db_product = crud.update_product(db, product_id, product_update.model_dump())
    if db_product is None:
        raise HTTPException(status_code=404, detail="Product not found")
    return db_product

@router.delete("/{product_id}", response_model=Product)
def delete_existing_product(
    product_id: int, 
    db: Session = Depends(get_db),
    # Add dependency: User must have 'product:delete' permission
    current_user: User = Depends(require_permission("product:delete"))
):
    """
    Delete an existing product. Protected by 'product:delete' permission.
    """
    db_product = crud.delete_product(db, product_id=product_id)
    if db_product is None:
        raise HTTPException(status_code=404, detail="Product not found")
    return db_product