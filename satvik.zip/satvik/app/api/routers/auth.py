# app/api/routers/auth.py
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from datetime import timedelta
from jose import jwt, JWTError

from app.db.session import get_db
from app.schemas.token import Token
from app.schemas.user import UserCreate
from app.db.crud import user as user_crud
from app.core import security
from app.core.mail import send_verification_email
from app.core.config import settings
from app.core.password import verify_password
from app.schemas.user import User
from app.schemas.user import UserWithRoles

router = APIRouter()

@router.post("/register", status_code=status.HTTP_201_CREATED)
async def register_user(user: UserCreate, db: Session = Depends(get_db)):
    db_user = user_crud.get_user_by_email(db, email=user.email)
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    new_user = user_crud.create_user(db=db, user=user)
    
    verification_token = security.create_access_token(
        data={"sub": new_user.email, "scope": "email_verification"},
        expires_delta=timedelta(hours=1)
    )
    await send_verification_email(new_user.email, verification_token)
    
    return {"message": "Registration successful. Please check your email to verify your account."}

@router.get("/verify-email")
def verify_email(token: str, db: Session = Depends(get_db)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_400_BAD_REQUEST,
        detail="Could not validate credentials",
    )
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        if payload.get("scope") != "email_verification":
            raise credentials_exception
        email: str = payload.get("sub")
        if email is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception

    user = user_crud.get_user_by_email(db, email=email)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    if user.is_verified:
        return {"message": "Email has already been verified."}
    
    user.is_verified = True
    db.commit()
    return {"message": "Email verified successfully. You can now log in."}
    
@router.post("/token", response_model=Token)
def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = user_crud.get_user_by_email(db, email=form_data.username)
    # Use the newly imported verify_password function
    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    if not user.is_verified:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Account not verified. Please check your email for a verification link.",
        )
    if not user.is_active:
        raise HTTPException(status_code=400, detail="Inactive user")

    access_token = security.create_access_token(data={"sub": user.email})
    return {"access_token": access_token, "token_type": "bearer"}

@router.get("/verify-manually/{email}")
def verify_manually(email: str, db: Session = Depends(get_db)):
    """
    TEMPORARY DEVELOPMENT ENDPOINT to manually verify a user.
    This bypasses the need to click the email link.
    """
    user = user_crud.get_user_by_email(db, email=email)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    if user.is_verified:
        return {"message": f"User {email} is already verified."}

    user.is_verified = True
    db.commit()
    
    return {"message": f"User {email} has been manually verified successfully."}


@router.get("/me", response_model=UserWithRoles)
def read_users_me(current_user: User = Depends(security.get_current_user)):
    """
    Fetch the profile of the currently logged-in user.
    """
    return current_user