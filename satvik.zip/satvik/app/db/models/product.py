from sqlalchemy import Column, Integer, String, Float
from app.db.session import Base

class Product(Base):
    __tablename__ = "products"

    product_id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    description = Column(String, nullable=True)
    cost_price = Column(Float)
    selling_price = Column(Float)
    category = Column(String, index=True)
    stock_available = Column(Integer)
    units_sold = Column(Integer)
    customer_rating = Column(Integer)