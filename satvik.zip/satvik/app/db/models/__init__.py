# Import all models to ensure they are registered with SQLAlchemy
from .user import User
from .role import Role
from .permission import Permission
from .product import Product

# Make sure all models are available when importing from this module
__all__ = ["User", "Role", "Permission", "Product"]
