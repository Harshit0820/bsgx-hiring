# app/db/models/permission.py
from sqlalchemy import Column, Integer, String, Table, ForeignKey
from sqlalchemy.orm import relationship
from app.db.session import Base

# This is an "association table" that links Roles and Permissions in a many-to-many relationship.
role_permissions_association = Table(
    'role_permissions', Base.metadata,
    Column('role_id', Integer, ForeignKey('roles.id', ondelete="CASCADE")),
    Column('permission_id', Integer, ForeignKey('permissions.id', ondelete="CASCADE"))
)

class Permission(Base):
    __tablename__ = 'permissions'
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True) # e.g., "product:create", "product:read"
    description = Column(String, nullable=True)

    # This relationship will be used later
    roles = relationship("Role", secondary=role_permissions_association, back_populates="permissions")