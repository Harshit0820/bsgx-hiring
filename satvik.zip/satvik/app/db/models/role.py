# app/db/models/role.py
from sqlalchemy import Column, Integer, String, Table, ForeignKey, Boolean
from sqlalchemy.orm import relationship
from app.db.session import Base
from .permission import role_permissions_association # Import the association table

# This is another association table that links Users and Roles (many-to-many).
user_roles_association = Table(
    'user_roles', Base.metadata,
    Column('user_id', Integer, ForeignKey('users.id', ondelete="CASCADE")),
    Column('role_id', Integer, ForeignKey('roles.id', ondelete="CASCADE"))
)

class Role(Base):
    __tablename__ = 'roles'
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)
    description = Column(String, nullable=True)
    default_role = Column(Boolean, default=False, nullable=False)

    # This defines the many-to-many relationship to the Permission model.
    permissions = relationship("Permission", secondary=role_permissions_association, back_populates="roles")
    # This defines the many-to-many relationship back to the User model.
    users = relationship("User", secondary=user_roles_association, back_populates="roles")