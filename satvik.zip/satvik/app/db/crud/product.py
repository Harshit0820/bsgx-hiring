# app/db/crud/product.py
from sqlalchemy.orm import Session
from typing import List, Optional
import random
from datetime import datetime, timedelta

from app.db.models.product import Product
from app.schemas.product import ProductCreate

def get_product(db: Session, product_id: int) -> Optional[Product]:
    """Gets a single product by its ID."""
    return db.query(Product).filter(Product.product_id == product_id).first()

def get_products(db: Session, skip: int = 0, limit: int = 100, category: Optional[str] = None, search: Optional[str] = None) -> List[Product]:
    """
    Gets a list of products with filtering and searching.
    - category: Filters products by the specified category.
    - search: Performs a case-insensitive search on the product name.
    """
    query = db.query(Product)

    if category:
        query = query.filter(Product.category == category)

    if search:
        # Using ilike for case-insensitive search
        query = query.filter(Product.name.ilike(f"%{search}%"))

    return query.offset(skip).limit(limit).all()

def create_product(db: Session, product: ProductCreate) -> Product:
    """Creates a new product in the database."""
    db_product = Product(**product.model_dump())
    db.add(db_product)
    db.commit()
    db.refresh(db_product)
    return db_product

def update_product(db: Session, product_id: int, product_data: dict) -> Optional[Product]:
    """Updates an existing product."""
    db_product = get_product(db, product_id)
    if db_product:
        for key, value in product_data.items():
            setattr(db_product, key, value)
        db.commit()
        db.refresh(db_product)
    return db_product

def delete_product(db: Session, product_id: int) -> Optional[Product]:
    """Deletes a product from the database."""
    db_product = get_product(db, product_id)
    if db_product:
        db.delete(db_product)
        db.commit()
    return db_product

def get_unique_product_categories(db: Session) -> List[str]:
    """Gets a list of unique product categories."""
    return [category[0] for category in db.query(Product.category).distinct().all()]

def get_optimized_prices(db: Session, category: Optional[str] = None, search: Optional[str] = None) -> List[dict]:
    """
    Calculates an optimized selling price for all products based on supply and demand,
    with optional filtering by category and search by name.
    """
    query = db.query(Product)
    if category:
        query = query.filter(Product.category == category)
    if search:
        query = query.filter(Product.name.ilike(f"%{search}%"))

    products = query.all()
    optimized_products = []

    for product in products:
        # Simple supply and demand logic
        demand_factor = (product.units_sold or 1) / (product.stock_available or 1)
        
        price_adjustment = 1.0
        if demand_factor > 1.5: # High demand
            price_adjustment = 1.1
        elif demand_factor < 0.5: # Low demand
            price_adjustment = 0.9
            
        optimized_price = float(product.selling_price) * price_adjustment
        
        # Ensure optimized price is not below cost price
        optimized_price = max(optimized_price, float(product.cost_price))
        
        product_dict = product.__dict__
        product_dict['optimized_price'] = round(optimized_price, 2)
        optimized_products.append(product_dict)
        
    return optimized_products

def get_demand_forecast_for_product(db: Session, product_id: int) -> List[dict]:
    """
    Generates a simulated demand forecast for a given product.
    In a real application, this would involve a complex data model.
    """
    # Simulate fetching historical data and running a forecast model
    # For now, we'll generate some random data for the next 3 months
    today = datetime.now()
    forecast_data = []
    
    # Base demand on a product characteristic to make it consistent
    product = db.query(Product).filter(Product.product_id == product_id).first()
    if not product:
        return []
        
    base_demand = (product.units_sold or 100) / 12 # Monthly average
    
    for i in range(12):
        month = today + timedelta(days=i*30)
        # Add some seasonality and randomness
        seasonal_factor = 1 + 0.3 * (1 if 6 <= month.month <= 8 else -1) # Summer peak
        random_factor = random.uniform(0.9, 1.1)
        
        demand = int(base_demand * seasonal_factor * random_factor)
        
        forecast_data.append({
            "date": month.strftime("%Y-%m-%d"),
            "product_id": product_id,
            "product_name": product.name,
            "predicted_demand": demand,
            "predicted_selling_price": float(product.selling_price) * random.uniform(0.95, 1.05)
        })
        
    return forecast_data