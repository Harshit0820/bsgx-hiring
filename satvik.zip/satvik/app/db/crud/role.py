# app/db/crud/role.py
from sqlalchemy.orm import Session
from typing import List
from app.db.models.role import Role
from app.db.models.user import User
from app.db.models.permission import Permission

def get_role_by_name(db: Session, role_name: str) -> Role | None:
    return db.query(Role).filter(Role.name == role_name).first()

def get_role_by_id(db: Session, role_id: int) -> Role | None:
    return db.query(Role).filter(Role.id == role_id).first()

def get_permission_by_id(db: Session, permission_id: int) -> Permission | None:
    return db.query(Permission).filter(Permission.id == permission_id).first()

def get_roles(db: Session, skip: int = 0, limit: int = 100) -> List[Role]:
    return db.query(Role).offset(skip).limit(limit).all()

def get_permissions(db: Session, skip: int = 0, limit: int = 100) -> List[Permission]:
    return db.query(Permission).offset(skip).limit(limit).all()

def create_role(db: Session, name: str, description: str | None, permission_ids: List[int]) -> Role:
    db_role = Role(name=name, description=description)
    if permission_ids:
        permissions = db.query(Permission).filter(Permission.id.in_(permission_ids)).all()
        db_role.permissions.extend(permissions)
    db.add(db_role)
    db.commit()
    db.refresh(db_role)
    return db_role

def assign_role_to_user(db: Session, user: User, role: Role):
    if role not in user.roles:
        user.roles.append(role)
        db.commit()

def remove_role_from_user(db: Session, user: User, role: Role):
    if role in user.roles:
        user.roles.remove(role)
        db.commit()

def update_role(db: Session, role: Role, name: str, description: str | None, permission_ids: List[int]) -> Role:
    role.name = name
    role.description = description
    
    # Clear existing permissions
    role.permissions.clear()
    
    # Add new permissions
    if permission_ids:
        permissions = db.query(Permission).filter(Permission.id.in_(permission_ids)).all()
        role.permissions.extend(permissions)
        
    db.commit()
    db.refresh(role)
    return role

def delete_role(db: Session, role: Role):
    db.delete(role)
    db.commit()