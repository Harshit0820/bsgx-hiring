import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { 
    getAllUsers,
    getAllRolesWithPermissions, 
    getAllPermissions,
    createRole, 
    updateRole,
    deleteRole as apiDeleteRole,
    assignRole as apiAssignRole,
    revokeRole as apiRevokeRole
} from '../../api/apiService';

// --- Async Thunks ---

export const fetchUsers = createAsyncThunk(
  'admin/fetchUsers',
  async (_, { rejectWithValue }) => {
    try {
      const response = await getAllUsers();
      return response.data;
    } catch (err) {
      return rejectWithValue(err.response?.data?.detail || 'Could not fetch users.');
    }
  }
);

export const fetchRoles = createAsyncThunk(
  'admin/fetchRoles',
  async (_, { rejectWithValue }) => {
    try {
      const response = await getAllRolesWithPermissions();
      return response.data;
    } catch (err) {
      return rejectWithValue(err.response?.data?.detail || 'Could not fetch roles.');
    }
  }
);

export const fetchPermissions = createAsyncThunk(
  'admin/fetchPermissions',
  async (_, { rejectWithValue }) => {
    try {
      const response = await getAllPermissions();
      return response.data;
    } catch (err) {
      return rejectWithValue(err.response?.data?.detail || 'Could not fetch permissions.');
    }
  }
);

export const saveRole = createAsyncThunk(
  'admin/saveRole',
  async (roleData, { dispatch, rejectWithValue }) => {
    try {
      const { id, ...data } = roleData;
      if (id) {
        await updateRole(id, data);
      } else {
        await createRole(data);
      }
      dispatch(fetchRoles()); // Refresh the roles list after saving
    } catch (err) {
      return rejectWithValue(err.response?.data?.detail || 'Failed to save role.');
    }
  }
);

export const deleteRole = createAsyncThunk(
    'admin/deleteRole',
    async (roleId, { dispatch, rejectWithValue }) => {
        try {
            await apiDeleteRole(roleId);
            dispatch(fetchRoles()); // Refresh the roles list
            return roleId;
        } catch (err) {
            return rejectWithValue(err.response?.data?.detail || 'Failed to delete role.');
        }
    }
);

export const assignRole = createAsyncThunk(
    'admin/assignRole',
    async ({ userId, roleId }, { dispatch, rejectWithValue }) => {
        try {
            await apiAssignRole(userId, roleId);
            dispatch(fetchUsers());
        } catch (err) {
            return rejectWithValue(err.response?.data?.detail || 'Failed to assign role.');
        }
    }
);

export const revokeRole = createAsyncThunk(
    'admin/revokeRole',
    async ({ userId, roleId }, { dispatch, rejectWithValue }) => {
        try {
            await apiRevokeRole(userId, roleId);
            dispatch(fetchUsers());
        } catch (err) {
            return rejectWithValue(err.response?.data?.detail || 'Failed to revoke role.');
        }
    }
);

// --- Slice Definition ---

const adminSlice = createSlice({
  name: 'admin',
  initialState: {
    users: {
        data: [],
        status: 'idle', // 'idle' | 'loading' | 'succeeded' | 'failed'
    },
    roles: {
        data: [],
        status: 'idle',
    },
    permissions: {
        data: [],
        status: 'idle',
    },
    // General error for the slice, often from the last failed action
    error: null, 
  },
  reducers: {
    // Synchronous reducers can be added here if needed
  },
  extraReducers: (builder) => {
    // --- Cases for fetchUsers ---
    builder.addCase(fetchUsers.pending, (state) => {
        state.users.status = 'loading';
    });
    builder.addCase(fetchUsers.fulfilled, (state, action) => {
        state.users.status = 'succeeded';
        state.users.data = action.payload;
    });
    builder.addCase(fetchUsers.rejected, (state, action) => {
        state.users.status = 'failed';
        state.error = action.payload;
    });

    // --- Cases for fetchRoles ---
    builder.addCase(fetchRoles.pending, (state) => {
        state.roles.status = 'loading';
    });
    builder.addCase(fetchRoles.fulfilled, (state, action) => {
        state.roles.status = 'succeeded';
        state.roles.data = action.payload;
    });
    builder.addCase(fetchRoles.rejected, (state, action) => {
        state.roles.status = 'failed';
        state.error = action.payload;
    });
    
    // --- Cases for fetchPermissions ---
    builder.addCase(fetchPermissions.pending, (state) => { 
        state.permissions.status = 'loading'; 
    });
    builder.addCase(fetchPermissions.fulfilled, (state, action) => {
        state.permissions.status = 'succeeded';
        state.permissions.data = action.payload; 
    });
    builder.addCase(fetchPermissions.rejected, (state, action) => {
        state.permissions.status = 'failed';
        state.error = action.payload;
    });

    // --- Cases for saveRole ---
    builder.addCase(saveRole.pending, (state) => { 
        state.error = null;
    });
    builder.addCase(saveRole.fulfilled, (state) => { 
        // No status change needed here as fetchRoles will handle it
    });
    builder.addCase(saveRole.rejected, (state, action) => {
        state.error = action.payload;
    });

    // --- Cases for deleteRole ---
    builder.addCase(deleteRole.pending, (state) => {
        state.error = null;
    });
    builder.addCase(deleteRole.fulfilled, (state, action) => {
        // The list is refreshed by fetchRoles, so no need to manually remove here
    });
    builder.addCase(deleteRole.rejected, (state, action) => {
        state.error = action.payload;
    });

    // --- Cases for assignRole ---
    builder.addCase(assignRole.pending, (state) => {
        state.error = null;
    });
    builder.addCase(assignRole.fulfilled, (state) => {
        // Handled by fetchUsers
    });
    builder.addCase(assignRole.rejected, (state, action) => {
        state.error = action.payload;
    });

    // --- Cases for revokeRole ---
    builder.addCase(revokeRole.pending, (state) => {
        state.error = null;
    });
    builder.addCase(revokeRole.fulfilled, (state) => {
        // Handled by fetchUsers
    });
    builder.addCase(revokeRole.rejected, (state, action) => {
        state.error = action.payload;
    });
  },
});

export default adminSlice.reducer;