// src/store/slices/authSlice.js
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { loginUser, registerUser, getUserProfile } from '../../api/apiService';

// Thunk for handling user login
export const login = createAsyncThunk(
    'auth/login',
    async ({ email, password }, { dispatch, rejectWithValue }) => {
        try {
            const response = await loginUser(email, password);
            localStorage.setItem('token', response.data.access_token);
            // After login, fetch the user's profile
            dispatch(fetchUserProfile()); 
            return response.data;
        } catch (err) {
            return rejectWithValue(err.response?.data?.detail || 'Login failed.');
        }
    }
);

export const fetchUserProfile = createAsyncThunk(
    'auth/fetchUserProfile',
    async (_, { rejectWithValue }) => {
        try {
            const response = await getUserProfile();
            return response.data;
        } catch (err) {
            return rejectWithValue('Could not fetch user profile.');
        }
    }
);

export const register = createAsyncThunk(
  'auth/register',
  async ({ fullName, email, password }, { rejectWithValue }) => { // <<< ADD fullName
    try {
      const response = await registerUser(fullName, email, password); 
      return response.data;
    } catch (err) {
      return rejectWithValue(err.response?.data?.detail || 'Registration failed.');
    }
  }
);


const authSlice = createSlice({
  name: 'auth',
  initialState: {
    user: null, // This will hold the user's profile data
    loading: false,
    error: null,
  },
  reducers: {
    clearError: (state) => {
        state.error = null;
    },
    logout: (state) => {
        state.user = null;
        localStorage.removeItem('token');
    }
  },
  extraReducers: (builder) => {
    builder
      // Handle Login Thunk
      .addCase(login.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(login.fulfilled, (state) => {
        state.loading = false;
      })
      .addCase(login.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      // Handle Fetch User Profile Thunk
      .addCase(fetchUserProfile.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchUserProfile.fulfilled, (state, action) => {
        state.user = action.payload;
        state.loading = false;
      })
      .addCase(fetchUserProfile.rejected, (state, action) => {
        state.user = null;
        state.loading = false;
        state.error = action.payload;
      })
      // Handle Register Thunk
      .addCase(register.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(register.fulfilled, (state) => {
        state.loading = false;
      })
      .addCase(register.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export const { clearError, logout } = authSlice.actions;
export default authSlice.reducer;