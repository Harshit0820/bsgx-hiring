// src/store/slices/verificationSlice.js
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { verifyUserEmail } from '../../api/apiService';

export const verifyEmail = createAsyncThunk(
  'verification/verifyEmail',
  async (token, { rejectWithValue }) => {
    try {
      const response = await verifyUserEmail(token);
      return response.data;
    } catch (err) {
      return rejectWithValue(err.response?.data?.detail || 'Verification failed.');
    }
  }
);

const verificationSlice = createSlice({
  name: 'verification',
  initialState: {
    status: 'idle', // 'idle' | 'loading' | 'succeeded' | 'failed'
    message: '',
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(verifyEmail.pending, (state) => {
        state.status = 'loading';
        state.message = '';
      })
      .addCase(verifyEmail.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.message = action.payload.message;
      })
      .addCase(verifyEmail.rejected, (state, action) => {
        state.status = 'failed';
        state.message = action.payload;
      });
  },
});

export default verificationSlice.reducer;