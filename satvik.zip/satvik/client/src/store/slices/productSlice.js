import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { 
    getProducts, 
    deleteProduct as apiDeleteProduct, 
    getProductCategories,
    getDemandForecast as apiGetDemandForecast,
    updateProduct as apiUpdateProduct,
    createProduct as apiCreateProduct,
    getOptimizedPrices as apiGetOptimizedPrices
} from '../../api/apiService';

export const fetchProducts = createAsyncThunk(
    'products/fetchProducts',
    async (params = {}, { rejectWithValue }) => {
        try {
            const response = await getProducts(params);
            return response.data;
        } catch (err) {
            return rejectWithValue(err.response?.data?.detail || 'Could not fetch products.');
        }
    }
);

export const saveProduct = createAsyncThunk(
    'products/saveProduct',
    async (productData, { dispatch, rejectWithValue }) => {
        try {
            const { product_id, ...data } = productData;
            if (product_id) {
                await apiUpdateProduct(product_id, data);
            } else {
                await apiCreateProduct(data);
            }
            dispatch(fetchProducts());
            dispatch(fetchProductCategories());
        } catch (err) {
            return rejectWithValue(err.response?.data?.detail || 'Failed to save product.');
        }
    }
);

export const fetchOptimizedPrices = createAsyncThunk(
    'products/fetchOptimizedPrices',
    async (params = {}, { rejectWithValue }) => {
        try {
            const response = await apiGetOptimizedPrices(params);
            return response.data;
        } catch (err) {
            return rejectWithValue(err.response?.data?.detail || 'Could not fetch optimized prices.');
        }
    }
);

export const fetchProductCategories = createAsyncThunk(
    'products/fetchProductCategories',
    async (_, { rejectWithValue }) => {
        try {
            const response = await getProductCategories();
            return response.data;
        } catch (err) {
            return rejectWithValue(err.response?.data?.detail || 'Could not fetch categories.');
        }
    }
);

export const fetchDemandForecast = createAsyncThunk(
    'products/fetchDemandForecast',
    async (productId, { rejectWithValue }) => {
        try {
            const response = await apiGetDemandForecast(productId);
            return { productId, data: response.data };
        } catch (err) {
            return rejectWithValue({ productId, error: err.response?.data?.detail || 'Could not fetch forecast.' });
        }
    }
);

export const deleteProduct = createAsyncThunk(
    'products/deleteProduct',
    async (productId, { dispatch, rejectWithValue }) => {
        try {
            await apiDeleteProduct(productId);
            dispatch(fetchProducts()); // Refresh the product list
            return productId;
        } catch (err) {
            return rejectWithValue(err.response?.data?.detail || 'Failed to delete product.');
        }
    }
);

const productSlice = createSlice({
    name: 'products',
    initialState: {
        items: [],
        optimizedItems: [],
        categories: [],
        forecasts: {},
        status: 'idle', // 'idle' | 'loading' | 'succeeded' | 'failed'
        error: null,
    },
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(fetchProducts.pending, (state) => {
                state.status = 'loading';
            })
            .addCase(fetchProducts.fulfilled, (state, action) => {
                state.status = 'succeeded';
                state.items = action.payload;
            })
            .addCase(fetchProducts.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.payload;
            })
            .addCase(fetchOptimizedPrices.pending, (state) => {
                state.status = 'loading';
            })
            .addCase(fetchOptimizedPrices.fulfilled, (state, action) => {
                state.status = 'succeeded';
                state.optimizedItems = action.payload;
            })
            .addCase(fetchOptimizedPrices.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.payload;
            })
            .addCase(saveProduct.pending, (state) => {
                state.status = 'loading';
            })
            .addCase(saveProduct.fulfilled, (state) => {
                state.status = 'succeeded';
            })
            .addCase(saveProduct.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.payload;
            })
            .addCase(fetchProductCategories.pending, (state) => {
                // You might want a separate loading state for categories
            })
            .addCase(fetchProductCategories.fulfilled, (state, action) => {
                state.categories = action.payload;
            })
            .addCase(fetchProductCategories.rejected, (state, action) => {
                // Handle category fetch error
            })
            .addCase(fetchDemandForecast.pending, (state, action) => {
                const { meta: { arg: productId } } = action;
                state.forecasts[productId] = { status: 'loading', data: [] };
            })
            .addCase(fetchDemandForecast.fulfilled, (state, action) => {
                const { productId, data } = action.payload;
                state.forecasts[productId] = { status: 'succeeded', data };
            })
            .addCase(fetchDemandForecast.rejected, (state, action) => {
                const { productId, error } = action.payload;
                state.forecasts[productId] = { status: 'failed', error };
            })
            .addCase(deleteProduct.pending, (state) => {
                state.status = 'loading';
            })
            .addCase(deleteProduct.fulfilled, (state, action) => {
                state.status = 'succeeded';
            })
            .addCase(deleteProduct.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.payload;
            });
    },
});

export default productSlice.reducer;