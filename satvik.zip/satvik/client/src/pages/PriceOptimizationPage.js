import React, { useEffect, useState, useCallback, useMemo } from 'react';
import {
    Box, Typography, Button, CircularProgress, Alert,
    TextField, InputAdornment, Switch, FormControlLabel, IconButton
} from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';
import { useDispatch, useSelector } from 'react-redux';
import { fetchOptimizedPrices, fetchProductCategories } from '../store/slices/productSlice';
import { useNavigate } from 'react-router-dom';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import { debounce } from 'lodash';

const PriceOptimizationPage = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const { optimizedItems, categories, status, error } = useSelector((state) => state.products);
    
    const [searchQuery, setSearchQuery] = useState('');
    const [category, setCategory] = useState('');

    const debouncedFetch = useCallback(
        debounce((params) => {
            dispatch(fetchOptimizedPrices(params));
        }, 500),
        [dispatch]
    );

    useEffect(() => {
        dispatch(fetchProductCategories());
        dispatch(fetchOptimizedPrices());
    }, [dispatch]);

    useEffect(() => {
        const params = {};
        if (searchQuery) params.search = searchQuery;
        if (category) params.category = category;
        debouncedFetch(params);

        return () => {
            debouncedFetch.cancel();
        };
    }, [searchQuery, category, debouncedFetch]);


    const columns = useMemo(() => [
        { field: 'name', headerName: 'Product Name', width: 220 },
        { field: 'category', headerName: 'Product Category', width: 150 },
        { field: 'description', headerName: 'Description', flex: 1, sortable: false },
        {
            field: 'cost_price',
            headerName: 'Cost Price',
            type: 'number',
            width: 120,
            valueFormatter: (params) => `$${parseFloat(params).toFixed(2)}`,
        },
        {
            field: 'selling_price',
            headerName: 'Selling Price',
            type: 'number',
            width: 120,
            valueFormatter: (params) => `$${parseFloat(params).toFixed(2)}`,
        },
        {
            field: 'optimized_price',
            headerName: 'Optimized Price',
            type: 'number',
            width: 150,
            renderCell: (params) => (
                <Typography color="primary" sx={{ fontWeight: 'bold' }}>
                    ${parseFloat(params.value).toFixed(2)}
                </Typography>
            ),
        },
    ], []);

    return (
        <Box sx={{ width: '100%', p: 3, bgcolor: '#121212', color: 'white' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <IconButton onClick={() => navigate(-1)} sx={{ color: 'white' }}>
                    <ArrowBackIcon />
                </IconButton>
                <Typography variant="h5" component="h1" sx={{ ml: 2, fontWeight: 'bold' }}>
                    Pricing Optimization
                </Typography>
            </Box>

            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2, p: 2, bgcolor: '#1e1e1e', borderRadius: 1 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                    <FormControlLabel control={<Switch defaultChecked sx={{ '& .MuiSwitch-switchBase.Mui-checked': { color: 'primary.main' }, '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': { backgroundColor: 'primary.main' } }} />} label="With Demand Forecast" />
                    <TextField variant="outlined" size="small" placeholder="Search" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} sx={{ '& .MuiOutlinedInput-root': { bgcolor: '#333', borderRadius: '8px', '& fieldset': { borderColor: 'transparent' } }, '& .MuiInputBase-input': { color: 'white' } }} InputProps={{ startAdornment: (<InputAdornment position="start"><SearchIcon sx={{ color: 'grey.500' }} /></InputAdornment>), }} />
                    <TextField select value={category} onChange={(e) => setCategory(e.target.value)} size="small" SelectProps={{ native: true, sx: { bgcolor: '#333', color: 'white', borderRadius: '8px' } }} sx={{ '& .MuiNativeSelect-icon': { color: 'white' } }}>
                        <option value="">All Categories</option>
                        {categories.map((cat) => ( <option key={cat} value={cat} style={{ backgroundColor: '#333' }}>{cat}</option> ))}
                    </TextField>
                    <Button variant="outlined" startIcon={<FilterListIcon />} sx={{ borderColor: 'grey.700', color: 'white' }}>Filter</Button>
                </Box>
            </Box>

            {status === 'failed' && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

            <Box sx={{ height: 'calc(100vh - 250px)', width: '100%', bgcolor: '#1e1e1e', borderRadius: 1 }}>
                <DataGrid
                    rows={optimizedItems}
                    columns={columns}
                    getRowId={(row) => row.product_id}
                    loading={status === 'loading'}
                    sx={{
                        border: 'none',
                        color: 'white',
                        '& .MuiDataGrid-columnHeaders': { backgroundColor: '#333', borderBottom: '1px solid #444' },
                        '& .MuiDataGrid-cell': { borderBottom: '1px solid #444' },
                        '& .MuiDataGrid-footerContainer': { borderTop: '1px solid #444', color: 'white' },
                        '& .MuiTablePagination-root': { color: 'white' },
                        '& .MuiIconButton-root': { color: 'white' },
                    }}
                />
            </Box>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 2, gap: 2 }}>
                <Button variant="outlined" sx={{ borderColor: 'grey.700', color: 'white' }}>Cancel</Button>
                <Button variant="contained" color="primary">Save</Button>
            </Box>
        </Box>
    );
};

export default PriceOptimizationPage;