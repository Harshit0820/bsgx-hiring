import React from 'react';
import { Box, Typography, Grid } from '@mui/material';
import ActionCard from '../components/dashboard/ActionCard';

// Import icons for the cards
import InventoryIcon from '@mui/icons-material/Inventory';
import PriceCheckIcon from '@mui/icons-material/PriceCheck';

const DashboardPage = () => {
    return (
        <Box sx={{ textAlign: 'center', mt: 4 }}>
            {/* Main Title */}
            <Typography variant="h3" component="h1" sx={{ fontWeight: 'bold' }}>
                Price Optimization Tool
            </Typography>

            {/* Subtitle */}
            <Typography variant="h6" color="text.secondary" sx={{ mt: 1, mb: 6 }}>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            </Typography>

            {/* Grid container for the cards */}
            <Grid container spacing={4} justifyContent="center">
                {/* Card 1: Create and Manage Product */}
                <Grid>
                    <ActionCard 
                        icon={<InventoryIcon sx={{ fontSize: 40, color: 'primary.main' }} />}
                        title="Create and Manage Product"
                        description="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor."
                        to="/dashboard/products" // This will navigate to the product management page
                    />
                </Grid>

                {/* Card 2: Pricing Optimization */}
                <Grid>
                    <ActionCard 
                        icon={<PriceCheckIcon sx={{ fontSize: 40, color: 'primary.main' }} />}
                        title="Pricing Optimization"
                        description="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor."
                        to="/dashboard/price-optimization" // This will navigate to the optimization page
                    />
                </Grid>
            </Grid>
        </Box>
    );
};

export default DashboardPage;