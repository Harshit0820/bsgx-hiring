import React, { useState, useEffect } from 'react';
import { Link as RouterLink } from 'react-router-dom';
import { Box, TextField, Button, CircularProgress, Alert, Link, Typography, List, ListItem, ListItemIcon, ListItemText } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import { register, clearError } from '../store/slices/authSlice';
import CenteredFormLayout from '../layouts/CenteredFormLayout';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';

// --- Validation Helper Functions ---
const isEmailValid = (email) => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

const isPasswordStrong = (password) => {
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    return passwordRegex.test(password);
};

const RegisterPage = () => {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const [validationErrors, setValidationErrors] = useState({});
  const [touched, setTouched] = useState({});

  const dispatch = useDispatch();
  const { loading, error: apiError } = useSelector((state) => state.auth);

  useEffect(() => {
    dispatch(clearError());
  }, [dispatch]);
  
  useEffect(() => {
    const validate = () => {
        const newErrors = {};
        if (touched.fullName && !fullName) newErrors.fullName = "Full name is required.";
        if (touched.email && !isEmailValid(email)) newErrors.email = "Please enter a valid email address.";
        if (touched.password && !isPasswordStrong(password)) newErrors.password = "Password does not meet the criteria.";
        if (touched.confirmPassword && password !== confirmPassword) newErrors.confirmPassword = "Passwords do not match.";
        
        setValidationErrors(newErrors);
    };
    validate();
  }, [fullName, email, password, confirmPassword, touched]);


  const handleBlur = (event) => {
    const { name } = event.target;
    setTouched({
      ...touched,
      [name]: true,
    });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setSuccessMessage('');
    
    const newErrors = {};
    if (!fullName) newErrors.fullName = "Full name is required.";
    if (!isEmailValid(email)) newErrors.email = "Please enter a valid email address.";
    if (!isPasswordStrong(password)) newErrors.password = "Password does not meet the criteria.";
    if (password !== confirmPassword) newErrors.confirmPassword = "Passwords do not match.";
    
    if (Object.keys(newErrors).length > 0) {
        setValidationErrors(newErrors);
        setTouched({fullName: true, email: true, password: true, confirmPassword: true});
        return;
    }

    const resultAction = await dispatch(register({ fullName, email, password }));

    if (register.fulfilled.match(resultAction)) {
      setSuccessMessage(resultAction.payload.message);
    }
  };

  return (
    <CenteredFormLayout pageTitle="Create a New Account">
      <Box component="form" onSubmit={handleSubmit} noValidate>
        {/* Field for Full Name */}
        <TextField
          margin="normal" required fullWidth id="fullName"
          label="Full Name" name="fullName" autoComplete="name"
          autoFocus
          value={fullName}
          onChange={(e) => setFullName(e.target.value)}
          error={!!validationErrors.fullName}
          helperText={validationErrors.fullName}
          onBlur={handleBlur}
        />
        {/* Field for Email */}
        <TextField
          margin="normal" required fullWidth id="email"
          label="Email Address" name="email" autoComplete="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          error={!!validationErrors.email}
          helperText={validationErrors.email}
          onBlur={handleBlur}
        />
        {/* Field for Password */}
        <TextField
          margin="normal" required fullWidth name="password"
          label="Password" type="password" id="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          error={!!validationErrors.password}
          onBlur={handleBlur}
        />
        
        <List dense sx={{color: 'text.secondary', mt: 1}}>
            <ListItem sx={{py: 0.2}}>
                <ListItemIcon sx={{minWidth: '32px'}}>{password.length >= 8 ? <CheckCircleOutlineIcon fontSize="small" color="success"/> : <HighlightOffIcon fontSize="small" color="error"/>}</ListItemIcon>
                <ListItemText primary="At least 8 characters" />
            </ListItem>
            <ListItem sx={{py: 0.2}}>
                 <ListItemIcon sx={{minWidth: '32px'}}>{/(?=.*[A-Z])/.test(password) ? <CheckCircleOutlineIcon fontSize="small" color="success"/> : <HighlightOffIcon fontSize="small" color="error"/>}</ListItemIcon>
                <ListItemText primary="One uppercase letter" />
            </ListItem>
             <ListItem sx={{py: 0.2}}>
                <ListItemIcon sx={{minWidth: '32px'}}>{/(?=.*\d)/.test(password) ? <CheckCircleOutlineIcon fontSize="small" color="success"/> : <HighlightOffIcon fontSize="small" color="error"/>}</ListItemIcon>
                <ListItemText primary="One number" />
            </ListItem>
            <ListItem sx={{py: 0.2}}>
                <ListItemIcon sx={{minWidth: '32px'}}>{/(?=.*[@$!%*?&])/.test(password) ? <CheckCircleOutlineIcon fontSize="small" color="success"/> : <HighlightOffIcon fontSize="small" color="error"/>}</ListItemIcon>
                <ListItemText primary="One special character" />
            </ListItem>
        </List>

        {/* Field for Confirm Password */}
        <TextField
          margin="normal" required fullWidth name="confirmPassword"
          label="Confirm Password" type="password" id="confirmPassword"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          error={!!validationErrors.confirmPassword}
          helperText={validationErrors.confirmPassword}
          onBlur={handleBlur}
        />
        
        {apiError && <Alert severity="error" sx={{ width: '100%', mt: 2 }}>{apiError}</Alert>}
        {successMessage && <Alert severity="success" sx={{ width: '100%', mt: 2 }}>{successMessage}</Alert>}

        <Button
          type="submit" fullWidth variant="contained" disabled={loading || !!successMessage}
          sx={{ mt: 3, mb: 2, py: 1.5, fontSize: '1rem' }}
        >
          {loading ? <CircularProgress size={26} color="inherit" /> : 'Create Account'}
        </Button>
        <Box textAlign="center">
          <Link component={RouterLink} to="/login" variant="body2" sx={{color: 'primary.main'}}>
            {"Already have an account? Sign In"}
          </Link>
        </Box>
      </Box>
    </CenteredFormLayout>
  );
};

export default RegisterPage;