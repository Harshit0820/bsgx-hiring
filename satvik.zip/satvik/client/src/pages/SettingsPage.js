import React, { useState } from 'react';
import { Box, Typography, Tabs, Tab, Paper } from '@mui/material';

// Import the two components that will act as our tab panels
import UserManagementTab from '../components/admin/UserManagementTab';
import RoleManagementTab from '../components/admin/RoleManagementTab'; // We will create this next

const SettingsPage = () => {
    const [currentTab, setCurrentTab] = useState(0);

    const handleTabChange = (event, newValue) => {
        setCurrentTab(newValue);
    };

    return (
        <Box>
            <Typography variant="h4" component="h1" gutterBottom>
                Settings
            </Typography>
            
            <Paper elevation={3} sx={{ mt: 2 }}>
                <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                    <Tabs value={currentTab} onChange={handleTabChange} aria-label="settings tabs">
                        <Tab label="User Management" id="tab-0" />
                        <Tab label="Role Management" id="tab-1" />
                    </Tabs>
                </Box>
                
                {/* Tab Panel for User Management */}
                <Box sx={{ p: 3 }} hidden={currentTab !== 0}>
                    <UserManagementTab />
                </Box>
                
                {/* Tab Panel for Role Management */}
                <Box sx={{ p: 3 }} hidden={currentTab !== 1}>
                    <RoleManagementTab />
                </Box>
            </Paper>
        </Box>
    );
};

export default SettingsPage;