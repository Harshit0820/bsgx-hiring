// src/pages/EmailVerificationPage.js
import React, { useEffect } from 'react';
import { useSearchParams, Link as RouterLink } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { verifyEmail } from '../store/slices/verificationSlice';
import { Container, Box, Typography, CircularProgress, Alert, Button } from '@mui/material';

const EmailVerificationPage = () => {
  const [searchParams] = useSearchParams();
  const dispatch = useDispatch();
  const { status, message } = useSelector((state) => state.verification);

  useEffect(() => {
    const token = searchParams.get('token');
    if (token && status === 'idle') {
      dispatch(verifyEmail(token));
    }
  }, [dispatch, searchParams, status]);

  return (
    <Container component="main" maxWidth="sm">
      <Box
        sx={{
          marginTop: 8, display: 'flex', flexDirection: 'column', alignItems: 'center',
          p: 4, bgcolor: 'background.paper', borderRadius: 2, textAlign: 'center'
        }}
      >
        <Typography component="h1" variant="h5" sx={{ mb: 2 }}>
          Email Verification
        </Typography>
        {status === 'loading' && <CircularProgress />}
        {status === 'succeeded' && <Alert severity="success">{message}</Alert>}
        {status === 'failed' && <Alert severity="error">{message}</Alert>}
        
        <Button
            component={RouterLink}
            to="/login"
            variant="contained"
            sx={{ mt: 3 }}
        >
            Proceed to Login
        </Button>
      </Box>
    </Container>
  );
};

export default EmailVerificationPage;