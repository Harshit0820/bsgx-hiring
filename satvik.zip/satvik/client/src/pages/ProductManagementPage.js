// src/pages/ProductManagementPage.js
import React, { useEffect, useState, useCallback, useMemo } from 'react';
import {
    Box, Typography, Button, CircularProgress, Alert,
    TextField, InputAdornment, Tooltip, IconButton, FormControlLabel, Switch,
    Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle
} from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';
import { useDispatch, useSelector } from 'react-redux';
import { 
    fetchProducts, 
    deleteProduct, 
    fetchProductCategories,
    fetchDemandForecast 
} from '../store/slices/productSlice';
import AddIcon from '@mui/icons-material/Add';
import SearchIcon from '@mui/icons-material/Search';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import VisibilityIcon from '@mui/icons-material/Visibility';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import ProductEditModal from '../components/products/ProductEditModal';
import ProductViewModal from '../components/products/ProductViewModal';
import DemandForecastModal from '../components/products/DemandForecastModal';
import { useNavigate } from 'react-router-dom';
import { debounce } from 'lodash';
import { usePermissions } from '../hooks/usePermissions';

const ProductManagementPage = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const { items: products, categories, forecasts, status, error } = useSelector((state) => state.products);
    const { hasPermission } = usePermissions();
    
    const [modalOpen, setModalOpen] = useState(false);
    const [selectedProduct, setSelectedProduct] = useState(null);
    const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
    const [productToDelete, setProductToDelete] = useState(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [category, setCategory] = useState('');
    const [forecastModalOpen, setForecastModalOpen] = useState(false);
    const [selectedRows, setSelectedRows] = useState([]);
    const [viewModalOpen, setViewModalOpen] = useState(false);
    const [showForecast, setShowForecast] = useState(false);

    const selectedIds = useMemo(() => {
        if (Array.isArray(selectedRows)) {
            return selectedRows;
        }
        if (selectedRows.type === 'exclude') {
            const allIds = products.map(p => p.product_id);
            const excludedIds = new Set(selectedRows.ids);
            return allIds.filter(id => !excludedIds.has(id));
        }
        return Array.from(selectedRows.ids || []);
    }, [selectedRows, products]);

    const debouncedFetchProducts = useCallback(
        debounce((params) => {
            dispatch(fetchProducts(params));
        }, 500),
        [dispatch]
    );

    useEffect(() => {
        dispatch(fetchProductCategories());
        dispatch(fetchProducts());
    }, [dispatch]);

    useEffect(() => {
        const params = {};
        if (searchQuery) params.search = searchQuery;
        if (category) params.category = category;

        debouncedFetchProducts(params);
        
        return () => {
            debouncedFetchProducts.cancel();
        };
    }, [searchQuery, category, debouncedFetchProducts]);

    useEffect(() => {
        if (showForecast) {
            products.forEach(product => {
                if (!forecasts[product.product_id]) {
                    dispatch(fetchDemandForecast(product.product_id));
                }
            });
        }
    }, [showForecast, products, forecasts, dispatch]);

    const handleView = useCallback((product) => {
        setSelectedProduct(product);
        setViewModalOpen(true);
    }, []);
    
    const handleEdit = useCallback((product) => {
        setSelectedProduct(product);
        setModalOpen(true);
    }, []);

    const handleOpenDeleteDialog = useCallback((id, name) => {
        setProductToDelete({ id, name });
        setDeleteDialogOpen(true);
    }, []);

    const handleCloseDeleteDialog = useCallback(() => {
        setProductToDelete(null);
        setDeleteDialogOpen(false);
    }, []);

    const handleConfirmDelete = useCallback(() => {
        if (productToDelete) {
            dispatch(deleteProduct(productToDelete.id));
        }
        handleCloseDeleteDialog();
    }, [productToDelete, dispatch, handleCloseDeleteDialog]);

    const handleOpenForecastModal = useCallback(() => {
        selectedIds.forEach(productId => {
            if (!forecasts[productId] || forecasts[productId].status !== 'succeeded') {
                dispatch(fetchDemandForecast(productId));
            }
        });
        setForecastModalOpen(true);
    }, [selectedIds, forecasts, dispatch]);

    const handleSearchChange = useCallback((event) => {
        setSearchQuery(event.target.value);
    }, []);

    const handleCategoryChange = useCallback((event) => {
        setCategory(event.target.value);
    }, []);

    const columns = useMemo(() => {
        const baseColumns = [
            { field: 'product_id', headerName: 'Product ID', width: 120 },
            { field: 'name', headerName: 'Product Name', width: 220 },
            { field: 'category', headerName: 'Product Category', width: 150 },
            {
                field: 'cost_price',
                headerName: 'Cost Price',
                type: 'number',
                width: 120,
                valueFormatter: (params) => {
                    const value = parseFloat(params);
                    return !isNaN(value) ? `$${value.toFixed(2)}` : 'N/A';
                },
            },
            {
                field: 'selling_price',
                headerName: 'Selling Price',
                type: 'number',
                width: 120,
                valueFormatter: (params) => {
                    const value = parseFloat(params);
                    return !isNaN(value) ? `$${value.toFixed(2)}` : 'N/A';
                },
            },
            { field: 'description', headerName: 'Description', flex: 1, sortable: false },
            { field: 'stock_available', headerName: 'Available Stock', type: 'number', width: 150 },
            { field: 'units_sold', headerName: 'Units Sold', type: 'number', width: 120 },
        ];

        if (showForecast) {
            baseColumns.push({
                field: 'demand_forecast',
                headerName: 'Demand Forecast (12M)',
                width: 200,
                sortable: false,
                renderCell: (params) => {
                    const forecast = forecasts[params.row.product_id];
                    if (!forecast || forecast.status === 'loading') {
                        return <CircularProgress size={20} />;
                    }
                    if (forecast.status === 'succeeded') {
                        const totalDemand = forecast.data.reduce((acc, d) => acc + d.predicted_demand, 0);
                        return totalDemand.toLocaleString();
                    }
                    return 'N/A';
                }
            });
        }

        baseColumns.push({
            field: 'actions',
            headerName: 'Action',
            type: 'actions',
            width: 150,
            getActions: (params) => {
                const actions = [];
                actions.push(
                    <Tooltip title="View Details">
                        <IconButton onClick={() => handleView(params.row)}>
                            <VisibilityIcon />
                        </IconButton>
                    </Tooltip>
                );
                if (hasPermission('product:update')) {
                    actions.push(
                        <Tooltip title="Edit Product">
                            <IconButton onClick={() => handleEdit(params.row)}>
                                <EditIcon />
                            </IconButton>
                        </Tooltip>
                    );
                }
                if (hasPermission('product:delete')) {
                    actions.push(
                        <Tooltip title="Delete Product">
                            <IconButton onClick={() => handleOpenDeleteDialog(params.row.product_id, params.row.name)}>
                                <DeleteIcon color="error" />
                            </IconButton>
                        </Tooltip>
                    );
                }
                return actions;
            },
        });

        return baseColumns;
    }, [showForecast, forecasts, hasPermission, handleView, handleEdit, handleOpenDeleteDialog]);


    const handleOpenModal = useCallback((product = null) => {
        setSelectedProduct(product);
        setModalOpen(true);
    }, []);

    const handleCloseModal = useCallback(() => {
        setModalOpen(false);
        setSelectedProduct(null);
    }, []);

    return (
        <Box sx={{ width: '100%' }}>
            <Box sx={{ p: 3, pb: 0 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <IconButton onClick={() => navigate(-1)}>
                        <ArrowBackIcon />
                    </IconButton>
                    <Typography variant="h5" component="h1" sx={{ ml: 2, fontWeight: 'bold' }}>
                        Create and Manage Product
                    </Typography>
                </Box>
    
                <Box 
                    sx={{ 
                        display: 'flex', 
                        justifyContent: 'space-between', 
                        alignItems: 'center', 
                        mb: 2, 
                        p: 2, 
                        bgcolor: 'background.paper', 
                        borderRadius: 1 
                    }}
                >
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                        {hasPermission('forecast:read') && (
                            <FormControlLabel 
                                control={<Switch checked={showForecast} onChange={(e) => setShowForecast(e.target.checked)} />} 
                                label="With Demand Forecast" 
                            />
                        )}
                        <TextField
                            variant="outlined"
                            size="small"
                            placeholder="Search by product name..."
                            value={searchQuery}
                            onChange={handleSearchChange}
                            InputProps={{
                                startAdornment: (
                                    <InputAdornment position="start">
                                        <SearchIcon />
                                    </InputAdornment>
                                ),
                            }}
                        />
                        <TextField 
                            select 
                            value={category} 
                            onChange={handleCategoryChange} 
                            size="small" 
                            SelectProps={{ 
                                native: true,
                                displayEmpty: true
                            }}
                        >
                            <option value="">All Categories</option>
                            {categories.map((cat) => (
                                <option key={cat} value={cat}>{cat}</option>
                            ))}
                        </TextField>
                    </Box>
                    <Box sx={{ display: 'flex', gap: 2 }}>
                        {hasPermission('product:create') && (
                            <Button variant="contained" color="primary" startIcon={<AddIcon />} onClick={() => handleOpenModal()}>
                                Add New Products
                            </Button>
                        )}
                        {hasPermission('forecast:read') && (
                            <Button 
                                variant="outlined" 
                                onClick={handleOpenForecastModal}
                                disabled={selectedIds.length === 0}
                            >
                                Demand Forecast
                            </Button>
                        )}
                    </Box>
                </Box>
    
                {status === 'failed' && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
            </Box>

            <Box sx={{ height: 'calc(100vh - 250px)', width: '100%', bgcolor: 'background.paper' }}>
                <DataGrid
                    rows={products}
                    columns={columns}
                    getRowId={(row) => row.product_id}
                    loading={status === 'loading'}
                    checkboxSelection
                    disableRowSelectionOnClick
                    onRowSelectionModelChange={(newSelectionModel) => {
                        setSelectedRows(newSelectionModel);
                    }}
                    initialState={{
                        pagination: {
                            paginationModel: {
                                pageSize: 10,
                            },
                        },
                    }}
                    pageSizeOptions={[5, 10, 25]}
                    sx={{
                        border: 'none',
                        '& .MuiDataGrid-columnHeaders': {
                            backgroundColor: 'rgba(255, 255, 255, 0.08)',
                            borderBottom: '1px solid rgba(255, 255, 255, 0.12)',
                        },
                        '& .MuiDataGrid-cell': {
                            borderBottom: '1px solid rgba(255, 255, 255, 0.12)',
                        },
                        '& .MuiDataGrid-footerContainer': {
                             borderTop: '1px solid rgba(255, 255, 255, 0.12)',
                        },
                        '& .MuiDataGrid-row': {
                            border: 'none',
                        },
                    }}
                />
            </Box>
            
            <ProductEditModal
                open={modalOpen}
                onClose={handleCloseModal}
                product={selectedProduct}
            />

            <ProductViewModal
                open={viewModalOpen}
                onClose={() => setViewModalOpen(false)}
                product={selectedProduct}
            />

            {forecastModalOpen && (
                <DemandForecastModal
                    open={forecastModalOpen}
                    onClose={() => setForecastModalOpen(false)}
                    forecasts={forecasts}
                    products={products.filter(p => selectedIds.includes(p.product_id))}
                />
            )}

            <Dialog
                open={deleteDialogOpen}
                onClose={handleCloseDeleteDialog}
            >
                <DialogTitle>Confirm Deletion</DialogTitle>
                <DialogContent>
                    <DialogContentText>
                        Are you sure you want to delete the product "<b>{productToDelete?.name}</b>"? This action cannot be undone.
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseDeleteDialog}>Cancel</Button>
                    <Button onClick={handleConfirmDelete} color="error" variant="contained">
                        Delete
                    </Button>
                </DialogActions>
            </Dialog>
        </Box>
    );
};

export default ProductManagementPage;