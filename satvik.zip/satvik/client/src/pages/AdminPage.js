// src/pages/AdminPage.js
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchRoles } from '../store/slices/adminSlice';
import { Box, Typography, Paper, Accordion, AccordionSummary, AccordionDetails, Chip, CircularProgress, Alert } from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';

const AdminPage = () => {
    const dispatch = useDispatch();
    const { roles, error } = useSelector((state) => ({
        roles: state.admin.roles,
        error: state.admin.error,
    }));

    useEffect(() => {
        // Fetch roles when the component first loads
        if (roles.status === 'idle') {
            dispatch(fetchRoles());
        }
    }, [roles.status, dispatch]);

    if (roles.status === 'loading') {
        return <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}><CircularProgress /></Box>;
    }

    if (roles.status === 'failed') {
        return <Alert severity="error" sx={{ mt: 2 }}>{error}</Alert>;
    }

    return (
        <Box>
            <Typography variant="h4" gutterBottom>
                Role & Permission Management
            </Typography>
            <Paper elevation={3} sx={{ p: 2 }}>
                {roles.data.map((role) => (
                    <Accordion key={role.id} sx={{ bgcolor: 'background.default', my: 1 }}>
                        <AccordionSummary
                            expandIcon={<ExpandMoreIcon />}
                            aria-controls={`panel-${role.id}-content`}
                            id={`panel-${role.id}-header`}
                        >
                            <Typography variant="h6">{role.name}</Typography>
                        </AccordionSummary>
                        <AccordionDetails>
                            <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                                {role.description}
                            </Typography>
                            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                                {role.permissions.length > 0 ? (
                                    role.permissions.map(permission => (
                                        <Chip key={permission.id} label={permission.name} variant="outlined" />
                                    ))
                                ) : (
                                    <Typography variant="body2" fontStyle="italic">No permissions assigned.</Typography>
                                )}
                            </Box>
                        </AccordionDetails>
                    </Accordion>
                ))}
            </Paper>
        </Box>
    );
};

export default AdminPage;