import React from 'react';
import { Box, Drawer, List, ListItem, ListItemButton, ListItemIcon, ListItemText, Toolbar, Divider } from '@mui/material';
import Navbar from '../components/Navbar';
import { useNavigate, useLocation } from 'react-router-dom';

// Import icons for our navigation items
import DashboardIcon from '@mui/icons-material/Dashboard'; // Using a more appropriate icon for the main dashboard
import InventoryIcon from '@mui/icons-material/Inventory';
import PriceCheckIcon from '@mui/icons-material/PriceCheck';
import SettingsIcon from '@mui/icons-material/Settings';

const drawerWidth = 240; // Define the width of our sidebar

const DashboardLayout = ({ children }) => {
    const navigate = useNavigate();
    const location = useLocation();

    // --- KEY CHANGE: REMOVED THE CONDITIONAL ADMIN LOGIC ---
    // The navItems array is now static. Access control is handled by the router.
    const navItems = [
        { text: 'Dashboard', icon: <DashboardIcon />, path: '/dashboard' },
        { text: 'Product Management', icon: <InventoryIcon />, path: '/dashboard/products' },
        { text: 'Price Optimization', icon: <PriceCheckIcon />, path: '/dashboard/price-optimization' },
    ];

    return (
        <Box sx={{ display: 'flex' }}>
            <Navbar /> 

            <Drawer
                variant="permanent"
                sx={{
                    width: drawerWidth,
                    flexShrink: 0,
                    [`& .MuiDrawer-paper`]: { 
                        width: drawerWidth, 
                        boxSizing: 'border-box',
                        bgcolor: 'background.paper',
                        borderRight: '1px solid rgba(255, 255, 255, 0.12)'
                    },
                }}
            >
                <Toolbar /> {/* Spacer to push content below the main Navbar */}
                <Box sx={{ overflow: 'auto', display: 'flex', flexDirection: 'column', height: '100%' }}>
                    {/* Main navigation links */}
                    <List sx={{ flexGrow: 1 }}>
                        {navItems.map((item) => (
                            <ListItem key={item.text} disablePadding>
                                <ListItemButton
                                    onClick={() => navigate(item.path)}
                                    selected={location.pathname === item.path}
                                    sx={{
                                        '&.Mui-selected': {
                                            backgroundColor: 'rgba(41, 186, 116, 0.16)',
                                            '&:hover': { backgroundColor: 'rgba(41, 186, 116, 0.24)' }
                                        },
                                    }}
                                >
                                    <ListItemIcon sx={{ color: 'inherit' }}>{item.icon}</ListItemIcon>
                                    <ListItemText primary={item.text} />
                                </ListItemButton>
                            </ListItem>
                        ))}
                    </List>

                    {/* Bottom Settings Link */}
                    <Box>
                        <Divider />
                        <List>
                            <ListItem disablePadding>
                                <ListItemButton 
                                    onClick={() => navigate('/dashboard/settings')}
                                    selected={location.pathname === '/dashboard/settings'}
                                    sx={{
                                        '&.Mui-selected': {
                                            backgroundColor: 'rgba(41, 186, 116, 0.16)',
                                            '&:hover': { backgroundColor: 'rgba(41, 186, 116, 0.24)' }
                                        },
                                    }}
                                >
                                    <ListItemIcon><SettingsIcon /></ListItemIcon>
                                    <ListItemText primary="Settings" />
                                </ListItemButton>
                            </ListItem>
                        </List>
                    </Box>
                </Box>
            </Drawer>

            {/* The Main Content Area */}
            <Box component="main" sx={{ flexGrow: 1, p: 3, width: `calc(100% - ${drawerWidth}px)` }}>
                <Toolbar /> {/* Another spacer for the main content */}
                {children}
            </Box>
        </Box>
    );
};

export default DashboardLayout;