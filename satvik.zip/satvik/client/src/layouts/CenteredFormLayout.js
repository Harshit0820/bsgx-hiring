import React from 'react';
import { Container, Box, Typography } from '@mui/material';
import BarChartIcon from '@mui/icons-material/BarChart';

const CenteredFormLayout = ({ children, pageTitle }) => {
  return (
    <Box 
      sx={{ 
        display: 'flex', 
        justifyContent: 'center', 
        alignItems: 'center', 
        minHeight: '100vh' 
      }}
    >
      <Container component="main" maxWidth="xs">
        <Box
          sx={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            p: 4,
            bgcolor: 'background.paper',
            borderRadius: 2,
            boxShadow: '0px 10px 25px rgba(0, 0, 0, 0.5)',
          }}
        >
          <Box sx={{ mb: 2, display: 'flex', alignItems: 'center', color: 'primary.main' }}>
            <BarChartIcon sx={{ fontSize: 40, mr: 1 }} />
            <Typography component="h1" variant="h5" sx={{ fontWeight: 'bold' }}>
              BCG X
            </Typography>
          </Box>
          <Typography component="h2" variant="h6" color="text.secondary">
            {pageTitle}
          </Typography>
          <Box sx={{ mt: 3, width: '100%' }}>
            {children}
          </Box>
        </Box>
      </Container>
    </Box>
  );
};

export default CenteredFormLayout;