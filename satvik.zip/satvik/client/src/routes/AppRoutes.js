import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { CircularProgress, Box } from '@mui/material';

// --- Layout and Route Guards ---
import DashboardLayout from '../layouts/DashboardLayout';
import ProtectedRoute from './ProtectedRoute';
import AdminRoute from './AdminRoutes'; // We will use this for the settings page

// --- Page Components ---
import LoginPage from '../pages/LoginPage';
import RegisterPage from '../pages/RegisterPage';
import EmailVerificationPage from '../pages/EmailVerificationPage';
import DashboardPage from '../pages/DashboardPage';
import ProductManagementPage from '../pages/ProductManagementPage';
import PriceOptimizationPage from '../pages/PriceOptimizationPage';
import SettingsPage from '../pages/SettingsPage'; // The component that now shows role management

const AppRoutes = () => {
  const { token, loading } = useAuth();

  if (loading) {
    return (
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
            <CircularProgress />
        </Box>
    );
  }

  return (
    <Routes>
      {/* --- PUBLIC ROUTES --- */}
      <Route path="/login" element={!token ? <LoginPage /> : <Navigate to="/dashboard" />} />
      <Route path="/register" element={!token ? <RegisterPage /> : <Navigate to="/dashboard" />} />
      <Route path="/verify-email" element={<EmailVerificationPage />} />

      {/* --- PROTECTED ROUTES WRAPPER --- */}
      <Route 
        path="/dashboard/*" 
        element={
          <ProtectedRoute>
            <DashboardLayout>
              <Routes>
                {/* Standard user pages */}
                <Route path="/" element={<DashboardPage />} /> 
                <Route path="products" element={<ProductManagementPage />} />
                <Route path="price-optimization" element={<PriceOptimizationPage />} />
                
                {/* --- THIS IS THE KEY CHANGE --- */}
                {/* The settings page is now protected by the AdminRoute */}
                <Route 
                    path="settings" 
                    element={
                        <AdminRoute>
                            <SettingsPage /> 
                        </AdminRoute>
                    } 
                />
                
                {/* We no longer have a separate /admin route, as it's been merged into settings */}
              </Routes>
            </DashboardLayout>
          </ProtectedRoute>
        } 
      />
      
      {/* --- DEFAULT REDIRECT --- */}
      <Route path="*" element={<Navigate to={token ? "/dashboard" : "/login"} />} />
    </Routes>
  );
};

export default AppRoutes;