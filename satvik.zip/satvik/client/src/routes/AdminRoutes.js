// src/routes/AdminRoute.js
import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

const AdminRoute = ({ children }) => {
  const { user, loading } = useAuth();

  // Wait until the user's session is loaded
  if (loading) {
    return null; // Or a loading spinner
  }

  // Check if the user object exists and if their roles array includes a role named 'admin'
  const isAdmin = user && user.roles.some(role => role.name === 'admin');

  if (!isAdmin) {
    // If the user is not an admin, redirect them away from the admin page
    console.warn("Access denied: User is not an admin.");
    return <Navigate to="/dashboard" replace />;
  }

  // If the user is an admin, render the requested page
  return children;
};

export default AdminRoute;