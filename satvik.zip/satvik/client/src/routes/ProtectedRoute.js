// src/routes/ProtectedRoute.js
import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

const ProtectedRoute = ({ children }) => {
  const { token, loading } = useAuth();
  const location = useLocation();

  // While context is checking for a token, show nothing or a loader
  if (loading) {
    return null; // Or your main app loader component
  }

  // If there's no token, redirect to the login page
  if (!token) {
    // Save the location they were trying to go to, so we can redirect them back after login
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // If there is a token, render the requested page
  return children;
};

export default ProtectedRoute;