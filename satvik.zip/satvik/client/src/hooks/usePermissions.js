import { useSelector } from 'react-redux';
import { useMemo, useCallback } from 'react';

export const usePermissions = () => {
    const user = useSelector((state) => state.auth.user);

    const userPermissions = useMemo(() => new Set(
        user?.roles?.flatMap(role => role.permissions?.map(p => p.name) || []) || []
    ), [user]);

    const hasPermission = useCallback((permission) => {
        return userPermissions.has(permission);
    }, [userPermissions]);

    return { hasPermission };
};
