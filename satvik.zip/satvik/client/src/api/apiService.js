import axios from 'axios';
const apiClient = axios.create({
  baseURL: process.env.REACT_APP_API_BASE_URL || "http://127.0.0.1:8000/api/v1",
});

apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);


export const loginUser = (email, password) => {
  const formData = new URLSearchParams();
  formData.append('username', email);
  formData.append('password', password);
  return apiClient.post('/auth/token', formData, {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
  });
};

export const registerUser = (full_name,email, password) => {
  return apiClient.post('/auth/register', { full_name, email, password });
};

export const verifyUserEmail = (token) => {
  return apiClient.get(`/auth/verify-email?token=${token}`);
};

export const getUserProfile = () => { 
  return apiClient.get('/auth/me');
};

export const getProducts = (params) => {
  return apiClient.get('/products/', { params });
};

export const getProductCategories = () => {
    return apiClient.get('/products/categories');
};

export const getOptimizedPrices = (params) => {
    return apiClient.get('/products/optimize', { params });
};

export const getAllRolesWithPermissions = () => {
  return apiClient.get('/admin/roles');
};

export const getAllPermissions = () => apiClient.get('/admin/permissions');

export const createRole = (roleData) => apiClient.post('/admin/roles', roleData);

export const updateRole = (roleId, roleData) => {
  return apiClient.put(`/admin/roles/${roleId}`, roleData);
};

export const deleteRole = (roleId) => {
    return apiClient.delete(`/admin/roles/${roleId}`);
};

export const updateProduct = (productId, productData) => {
    return apiClient.put(`/products/${productId}`, productData);
};

export const createProduct = (productData) => {
    return apiClient.post('/products/', productData);
};

export const deleteProduct = (productId) => {
    return apiClient.delete(`/products/${productId}`);
};

export const getDemandForecast = (productId) => {
    return apiClient.get(`/products/${productId}/forecast`);
};

export const getAllUsers = () => {
  return apiClient.get('/admin/users');
};

export const assignRole = (userId, roleId) => {
    return apiClient.post(`/admin/users/${userId}/roles`, { role_id: roleId });
};

export const revokeRole = (userId, roleId) => {
    return apiClient.delete(`/admin/users/${userId}/roles/${roleId}`);
};