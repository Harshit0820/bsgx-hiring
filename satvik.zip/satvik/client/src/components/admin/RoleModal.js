import React, { useState, useEffect } from 'react';
import {
    Dialog, DialogTitle, Typography, DialogContent, DialogActions,
    Button, TextField, Box
} from '@mui/material';
import { useDispatch } from 'react-redux';
import { saveRole } from '../../store/slices/adminSlice';
import PermissionEditor from './PermissionEditor'; // Import the new component

const RoleModal = ({ open, onClose, role, allPermissions }) => {
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [selectedPermissions, setSelectedPermissions] = useState(new Set());
    const dispatch = useDispatch();

    const isDefaultRole = role?.default_role === true;

    useEffect(() => {
        if (role) {
            setName(role.name);
            setDescription(role.description || '');
            setSelectedPermissions(new Set(role.permissions.map(p => p.id)));
        } else {
            setName('');
            setDescription('');
            setSelectedPermissions(new Set());
        }
    }, [role, open]);

    const handleSave = () => {
        const roleData = {
            id: role?.id,
            name,
            description,
            permission_ids: Array.from(selectedPermissions),
        };
        dispatch(saveRole(roleData));
        onClose();
    };

    return (
        <Dialog open={open} onClose={onClose} fullWidth maxWidth="md">
            <DialogTitle>
                {isDefaultRole ? `View Role: ${name}` : (role ? 'Edit Role' : 'Create New Role')}
            </DialogTitle>
            <DialogContent>
                <TextField
                    autoFocus
                    margin="dense"
                    label="Role Name"
                    type="text"
                    fullWidth
                    variant="outlined"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    sx={{ mb: 2 }}
                    InputProps={{
                        readOnly: isDefaultRole,
                    }}
                />
                <TextField
                    margin="dense"
                    label="Description"
                    type="text"
                    fullWidth
                    variant="outlined"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    sx={{ mb: 3 }}
                    InputProps={{
                        readOnly: isDefaultRole,
                    }}
                />
                <Typography variant="h6" gutterBottom>Permissions</Typography>
                <Box sx={{ pointerEvents: isDefaultRole ? 'none' : 'auto' }}>
                    <PermissionEditor
                        allPermissions={allPermissions}
                        selectedPermissions={selectedPermissions}
                        onPermissionChange={setSelectedPermissions}
                    />
                </Box>
            </DialogContent>
            <DialogActions>
                <Button onClick={onClose}>Cancel</Button>
                {!isDefaultRole && (
                    <Button onClick={handleSave} variant="contained">Save</Button>
                )}
            </DialogActions>
        </Dialog>
    );
};

export default RoleModal;