import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchUsers, assignRole, revokeRole } from '../../store/slices/adminSlice';
import {
    Box, Typography, Paper, Table, TableBody, TableCell, TableContainer,
    TableHead, TableRow, Chip, CircularProgress, Alert, Button,
    Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle
} from '@mui/material';
import UserRoleModal from './UserRoleModal';

const UserManagementTab = () => {
    const dispatch = useDispatch();
    
    const { users, roles, error } = useSelector((state) => ({
        users: state.admin.users,
        roles: state.admin.roles,
        error: state.admin.error,
    }));

    const [roleModalOpen, setRoleModalOpen] = useState(false);
    const [selectedUser, setSelectedUser] = useState(null);
    const [revokeDialogOpen, setRevokeDialogOpen] = useState(false);
    const [userToRevoke, setUserToRevoke] = useState(null);

    useEffect(() => {
        if (users.status === 'idle') {
            dispatch(fetchUsers());
        }
    }, [dispatch, users.status]);

    const handleOpenRoleModal = (user) => {
        setSelectedUser(user);
        setRoleModalOpen(true);
    };

    const handleCloseRoleModal = () => {
        setSelectedUser(null);
        setRoleModalOpen(false);
    };

    const handleSaveRole = (roleId) => {
        if (selectedUser) {
            dispatch(assignRole({ userId: selectedUser.id, roleId }));
        }
    };

    const handleOpenRevokeDialog = (user) => {
        setUserToRevoke(user);
        setRevokeDialogOpen(true);
    };

    const handleCloseRevokeDialog = () => {
        setUserToRevoke(null);
        setRevokeDialogOpen(false);
    };

    const handleConfirmRevoke = () => {
        if (userToRevoke && userToRevoke.roles.length > 0) {
            dispatch(revokeRole({ userId: userToRevoke.id, roleId: userToRevoke.roles[0].id }));
        }
        handleCloseRevokeDialog();
    };

    const isLoading = users.status === 'loading';
    const isReady = users.status === 'succeeded';
    const hasError = users.status === 'failed';

    if (isLoading && !isReady) {
        return <CircularProgress />;
    }

    return (
        <Box>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
                <Typography variant="h5" component="h2">
                    Manage Users
                </Typography>
            </Box>
            
            {hasError && <Alert severity="error" sx={{ mb: 2 }}>{error || "An error occurred."}</Alert>}
            
            <TableContainer component={Paper}>
                <Table sx={{ minWidth: 650 }} aria-label="users table">
                    <TableHead>
                        <TableRow>
                            <TableCell sx={{ fontWeight: 'bold' }}>Full Name</TableCell>
                            <TableCell sx={{ fontWeight: 'bold' }}>Email</TableCell>
                            <TableCell sx={{ fontWeight: 'bold' }}>Role</TableCell>
                            <TableCell sx={{ fontWeight: 'bold' }}>Status</TableCell>
                            <TableCell sx={{ fontWeight: 'bold' }}>Actions</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {isReady && users.data.map((user) => (
                            <TableRow
                                key={user.id}
                                sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                            >
                                <TableCell component="th" scope="row">{user.full_name}</TableCell>
                                <TableCell>{user.email}</TableCell>
                                <TableCell>
                                    {user.roles && user.roles.length > 0 ? (
                                        <Chip 
                                            label={user.roles[0].name} 
                                            color="primary" 
                                            variant="outlined" 
                                            size="small"
                                        />
                                    ) : (
                                        <Chip 
                                            label="No Role" 
                                            color="default" 
                                            variant="outlined" 
                                            size="small"
                                        />
                                    )}
                                </TableCell>
                                <TableCell>
                                    <Chip 
                                        label={user.is_verified ? "Verified" : "Unverified"} 
                                        color={user.is_verified ? "success" : "warning"} 
                                        variant="outlined" 
                                        size="small"
                                    />
                                </TableCell>
                                <TableCell>
                                    {user.roles && user.roles.length > 0 ? (
                                        <>
                                            <Button size="small" onClick={() => handleOpenRoleModal(user)}>Change Role</Button>
                                            <Button size="small" color="error" onClick={() => handleOpenRevokeDialog(user)}>Revoke</Button>
                                        </>
                                    ) : (
                                        <Button size="small" variant="contained" onClick={() => handleOpenRoleModal(user)}>Assign Role</Button>
                                    )}
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>

            <UserRoleModal
                open={roleModalOpen}
                onClose={handleCloseRoleModal}
                onSave={handleSaveRole}
                user={selectedUser}
                roles={roles.data}
            />

            <Dialog
                open={revokeDialogOpen}
                onClose={handleCloseRevokeDialog}
            >
                <DialogTitle>Confirm Revoke</DialogTitle>
                <DialogContent>
                    <DialogContentText>
                        Are you sure you want to revoke the role from "<b>{userToRevoke?.full_name}</b>"?
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseRevokeDialog}>Cancel</Button>
                    <Button onClick={handleConfirmRevoke} color="error" variant="contained">
                        Revoke
                    </Button>
                </DialogActions>
            </Dialog>
        </Box>
    );
};

export default UserManagementTab;