import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchRoles, fetchPermissions, saveRole, deleteRole } from '../../store/slices/adminSlice';
import {
    Box, Typography, Button, Paper, Accordion, AccordionSummary,
    AccordionDetails, Chip, CircularProgress, Alert, IconButton, Divider, Stack, Tooltip,
    Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import RoleModal from './RoleModal';
import PermissionEditor from './PermissionEditor';

const RoleManagementTab = () => {
    const dispatch = useDispatch();
    
    const { roles, permissions, error } = useSelector((state) => ({
        roles: state.admin.roles,
        permissions: state.admin.permissions,
        error: state.admin.error,
    }));
    
    const [modalOpen, setModalOpen] = useState(false);
    const [selectedRoleForModal, setSelectedRoleForModal] = useState(null);
    const [expandedRole, setExpandedRole] = useState(null);
    
    // State to manage inline editing
    const [editingRole, setEditingRole] = useState(null);
    const [editedPermissions, setEditedPermissions] = useState(new Set());

    // State for the delete confirmation dialog
    const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
    const [roleToDelete, setRoleToDelete] = useState(null);

    useEffect(() => {
        if (roles.status === 'idle') {
            dispatch(fetchRoles());
        }
        if (permissions.status === 'idle') {
            dispatch(fetchPermissions());
        }
    }, [dispatch, roles.status, permissions.status]);

    const handleOpenModal = (role = null) => {
        setSelectedRoleForModal(role);
        setModalOpen(true);
    };

    const handleCloseModal = () => {
        setModalOpen(false);
        setSelectedRoleForModal(null);
    };

    const handleAccordionChange = (roleId) => {
        const newExpandedRole = expandedRole === roleId ? null : roleId;
        setExpandedRole(newExpandedRole);
        // If we are collapsing the accordion, cancel any pending edits
        if (newExpandedRole === null) {
            setEditingRole(null);
        }
    };

    const handleEditClick = (e, role) => {
        e.stopPropagation();
        setEditingRole(role);
        setEditedPermissions(new Set(role.permissions.map(p => p.id)));
        setExpandedRole(role.id); // Ensure the accordion is expanded
    };

    const handleCancelEdit = () => {
        setEditingRole(null);
    };
    
    const handleSaveEdit = () => {
        if (!editingRole) return;
        
        const roleData = {
            id: editingRole.id,
            name: editingRole.name,
            description: editingRole.description,
            permission_ids: Array.from(editedPermissions),
        };
        dispatch(saveRole(roleData));
        setEditingRole(null); // Exit editing mode
    };

    const handleOpenDeleteDialog = (e, role) => {
        e.stopPropagation();
        setRoleToDelete(role);
        setDeleteDialogOpen(true);
    };

    const handleCloseDeleteDialog = () => {
        setRoleToDelete(null);
        setDeleteDialogOpen(false);
    };

    const handleConfirmDelete = () => {
        if (roleToDelete) {
            dispatch(deleteRole(roleToDelete.id));
        }
        handleCloseDeleteDialog();
    };

    const isLoading = roles.status === 'loading' || permissions.status === 'loading';
    const isReady = roles.status === 'succeeded' && permissions.status === 'succeeded';
    const hasError = roles.status === 'failed' || permissions.status === 'failed';

    if (isLoading && !isReady) {
        return <CircularProgress />;
    }

    return (
        <Box>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
                <Typography variant="h5" component="h2">
                    Manage Roles & Permissions
                </Typography>
                <Button variant="contained" startIcon={<AddIcon />} onClick={() => handleOpenModal()}>
                    Create Custom Role
                </Button>
            </Box>
            
            {hasError && <Alert severity="error" sx={{ mb: 2 }}>{error || "An error occurred."}</Alert>}
            
            <Paper elevation={2} sx={{ p: 2, mt: 2 }}>
                {isReady && roles.data.length > 0 ? (
                    roles.data.map((role, index) => (
                        <Accordion 
                            key={role.id} 
                            expanded={expandedRole === role.id} 
                            onChange={() => handleAccordionChange(role.id)}
                            sx={{ 
                                boxShadow: 'none', 
                                '&:before': { display: 'none' },
                                '&.Mui-expanded': { margin: 0 }
                            }}
                        >
                            <AccordionSummary 
                                expandIcon={<ExpandMoreIcon />}
                                sx={{ 
                                    flexDirection: 'row-reverse',
                                    '& .MuiAccordionSummary-expandIconWrapper.Mui-expanded': { transform: 'rotate(180deg)' },
                                    '& .MuiAccordionSummary-content': { ml: 1 },
                                    py: 0,
                                }}
                            >
                                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '100%' }}>
                                    <Typography variant="h6" fontWeight="medium">{role.name}</Typography>
                                    <Stack direction="row" spacing={1}>
                                        <Tooltip title={role.default_role ? "Default roles cannot be edited" : "Edit role permissions"}>
                                            <span>
                                                <IconButton 
                                                    aria-label="edit role" 
                                                    onClick={(e) => handleEditClick(e, role)}
                                                    disabled={role.default_role}
                                                    sx={{ color: role.default_role ? 'grey.500' : 'primary.main' }}
                                                >
                                                    <EditIcon />
                                                </IconButton>
                                            </span>
                                        </Tooltip>
                                        <Tooltip title={role.default_role ? "Default roles cannot be deleted" : "Delete role"}>
                                            <span>
                                                <IconButton 
                                                    aria-label="delete role" 
                                                    onClick={(e) => handleOpenDeleteDialog(e, role)}
                                                    disabled={role.default_role}
                                                    sx={{ color: role.default_role ? 'grey.500' : 'error.main' }}
                                                >
                                                    <DeleteIcon />
                                                </IconButton>
                                            </span>
                                        </Tooltip>
                                    </Stack>
                                </Box>
                            </AccordionSummary>
                            <AccordionDetails sx={{ pt: 1, pb: 2, px: 2 }}>
                                <Typography variant="body2" color="text.secondary" sx={{ mb: 2, fontStyle: 'italic' }}>
                                    {role.description}
                                </Typography>
                                <Divider sx={{ my: 2 }} />
                                
                                {editingRole?.id === role.id ? (
                                    <>
                                        <Typography variant="subtitle1" fontWeight="bold" sx={{ mb: 1 }}>Edit Permissions</Typography>
                                        <PermissionEditor
                                            allPermissions={permissions.data}
                                            selectedPermissions={editedPermissions}
                                            onPermissionChange={setEditedPermissions}
                                        />
                                        <Stack direction="row" spacing={2} sx={{ mt: 2, justifyContent: 'flex-end' }}>
                                            <Button onClick={handleCancelEdit}>Cancel</Button>
                                            <Button onClick={handleSaveEdit} variant="contained">Save Changes</Button>
                                        </Stack>
                                    </>
                                ) : (
                                    <>
                                        <Typography variant="subtitle1" fontWeight="bold" sx={{ mb: 1 }}>Assigned Permissions</Typography>
                                        {role.permissions && role.permissions.length > 0 ? (
                                            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                                                {role.permissions.map(permission => (
                                                    <Chip key={permission.id} label={permission.name} variant="outlined" color="primary" />
                                                ))}
                                            </Box>
                                        ) : (
                                            <Typography variant="body2" color="text.secondary">No permissions assigned.</Typography>
                                        )}
                                    </>
                                )}
                            </AccordionDetails>
                            {index < roles.data.length - 1 && <Divider />}
                        </Accordion>
                    ))
                ) : (
                    <Typography variant="body1" color="text.secondary" align="center" sx={{ p: 3 }}>
                        No roles found. Start by creating a new role.
                    </Typography>
                )}
            </Paper>

            <RoleModal 
                open={modalOpen}
                onClose={handleCloseModal}
                role={selectedRoleForModal}
                allPermissions={permissions.data}
            />

            <Dialog
                open={deleteDialogOpen}
                onClose={handleCloseDeleteDialog}
            >
                <DialogTitle>Confirm Deletion</DialogTitle>
                <DialogContent>
                    <DialogContentText>
                        Are you sure you want to delete the role "<b>{roleToDelete?.name}</b>"? This action cannot be undone.
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseDeleteDialog}>Cancel</Button>
                    <Button onClick={handleConfirmDelete} color="error" variant="contained">
                        Delete
                    </Button>
                </DialogActions>
            </Dialog>
        </Box>
    );
};

export default RoleManagementTab;