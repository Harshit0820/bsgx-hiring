import React from 'react';
import {
    Box,
    Typography,
    FormGroup,
    FormControlLabel,
    Checkbox,
    Divider
} from '@mui/material';

const groupPermissions = (permissions) => {
    return permissions.reduce((acc, permission) => {
        const [group] = permission.name.split(':');
        if (!acc[group]) {
            acc[group] = [];
        }
        acc[group].push(permission);
        return acc;
    }, {});
};

const PermissionEditor = ({ allPermissions, selectedPermissions, onPermissionChange }) => {
    const groupedPermissions = groupPermissions(allPermissions);

    const handleGroupChange = (groupName, isChecked) => {
        const groupPermissionIds = groupedPermissions[groupName].map(p => p.id);
        const newSelection = new Set(selectedPermissions);

        if (isChecked) {
            groupPermissionIds.forEach(id => newSelection.add(id));
        } else {
            groupPermissionIds.forEach(id => newSelection.delete(id));
        }
        onPermissionChange(newSelection);
    };

    const handleSinglePermissionChange = (permissionId) => {
        const newSelection = new Set(selectedPermissions);
        if (newSelection.has(permissionId)) {
            newSelection.delete(permissionId);
        } else {
            newSelection.add(permissionId);
        }
        onPermissionChange(newSelection);
    };

    return (
        <FormGroup>
            {Object.entries(groupedPermissions).map(([groupName, permissions]) => {
                const groupPermissionIds = permissions.map(p => p.id);
                const isGroupSelected = groupPermissionIds.every(id => selectedPermissions.has(id));
                const isGroupIndeterminate = groupPermissionIds.some(id => selectedPermissions.has(id)) && !isGroupSelected;

                return (
                    <Box key={groupName} sx={{ mb: 2 }}>
                        <FormControlLabel
                            control={
                                <Checkbox
                                    checked={isGroupSelected}
                                    indeterminate={isGroupIndeterminate}
                                    onChange={(e) => handleGroupChange(groupName, e.target.checked)}
                                />
                            }
                            label={<Typography variant="subtitle1" fontWeight="bold">{groupName.charAt(0).toUpperCase() + groupName.slice(1)}</Typography>}
                        />
                        <Box sx={{ display: 'flex', flexDirection: 'column', ml: 3, mt: 1 }}>
                            {permissions.map(permission => (
                                <FormControlLabel
                                    key={permission.id}
                                    control={<Checkbox checked={selectedPermissions.has(permission.id)} onChange={() => handleSinglePermissionChange(permission.id)} />}
                                    label={
                                        <Box>
                                            <Typography variant="body2">{permission.name}</Typography>
                                            <Typography variant="caption" color="text.secondary">{permission.description}</Typography>
                                        </Box>
                                    }
                                />
                            ))}
                        </Box>
                        <Divider sx={{ mt: 2 }} />
                    </Box>
                );
            })}
        </FormGroup>
    );
};

export default PermissionEditor;
