import React, { useState, useEffect } from 'react';
import {
    Dialog, DialogTitle, DialogContent, DialogActions,
    Button, Select, MenuItem, FormControl, InputLabel
} from '@mui/material';

const UserRoleModal = ({ open, onClose, onSave, user, roles }) => {
    const [selectedRoleId, setSelectedRoleId] = useState('');

    useEffect(() => {
        // Set the initial selected role if the user already has one
        if (user && user.roles && user.roles.length > 0) {
            setSelectedRoleId(user.roles[0].id);
        } else {
            setSelectedRoleId('');
        }
    }, [user, open]);

    const handleSave = () => {
        onSave(selectedRoleId);
        onClose();
    };

    return (
        <Dialog open={open} onClose={onClose} fullWidth maxWidth="xs">
            <DialogTitle>Change Role for {user?.full_name}</DialogTitle>
            <DialogContent>
                <FormControl fullWidth sx={{ mt: 2 }}>
                    <InputLabel id="role-select-label">Role</InputLabel>
                    <Select
                        labelId="role-select-label"
                        value={selectedRoleId}
                        onChange={(e) => setSelectedRoleId(e.target.value)}
                        label="Role"
                    >
                        {roles.map((role) => (
                            <MenuItem key={role.id} value={role.id}>
                                {role.name}
                            </MenuItem>
                        ))}
                    </Select>
                </FormControl>
            </DialogContent>
            <DialogActions>
                <Button onClick={onClose}>Cancel</Button>
                <Button onClick={handleSave} variant="contained">Save</Button>
            </DialogActions>
        </Dialog>
    );
};

export default UserRoleModal;
