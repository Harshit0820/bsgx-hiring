import React, { useMemo } from 'react';
import {
    Dialog, DialogTitle, DialogContent, Box, Typography,
    Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, IconButton
} from '@mui/material';
import {
    LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from 'recharts';
import CloseIcon from '@mui/icons-material/Close';

const DemandForecastModal = ({ open, onClose, forecasts, products }) => {

    const chartData = useMemo(() => {
        const dataMap = {};
        const colors = ['#8884d8', '#82ca9d', '#ffc658', '#ff7300', '#387908'];

        products.forEach((product, index) => {
            const forecast = forecasts[product.product_id];
            if (forecast?.status === 'succeeded') {
                forecast.data.forEach(d => {
                    const date = new Date(d.date).toLocaleString('default', { month: 'short', year: 'numeric' });
                    if (!dataMap[date]) {
                        dataMap[date] = { date };
                    }
                    dataMap[date][`${product.name}_demand`] = d.predicted_demand;
                    dataMap[date][`${product.name}_price`] = d.predicted_selling_price;
                    dataMap[date][`${product.name}_color`] = colors[index % colors.length];
                });
            }
        });
        return Object.values(dataMap);
    }, [forecasts, products]);

    return (
        <Dialog open={open} onClose={onClose} fullWidth maxWidth="xl">
            <DialogTitle>
                Demand Forecast
                <IconButton onClick={onClose} sx={{ position: 'absolute', right: 8, top: 8 }}>
                    <CloseIcon />
                </IconButton>
            </DialogTitle>
            <DialogContent>
                <Box sx={{ height: 400, mb: 4 }}>
                    <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={chartData}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="date" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            {products.map((p, index) => (
                                <Line
                                    key={p.product_id}
                                    type="monotone"
                                    dataKey={`${p.name}_demand`}
                                    name={`${p.name} Demand`}
                                    stroke={chartData[0]?.[`${p.name}_color`] || '#000'}
                                    yAxisId={0}
                                />
                            ))}
                             {products.map((p, index) => (
                                <Line
                                    key={`${p.product_id}-price`}
                                    type="monotone"
                                    dataKey={`${p.name}_price`}
                                    name={`${p.name} Selling Price`}
                                    stroke={chartData[0]?.[`${p.name}_color`]?.replace('8', '2') || '#000'}
                                    yAxisId={0}
                                />
                            ))}
                        </LineChart>
                    </ResponsiveContainer>
                </Box>
                <TableContainer component={Paper}>
                    <Table>
                        <TableHead>
                            <TableRow>
                                <TableCell>Product Name</TableCell>
                                <TableCell>Product Category</TableCell>
                                <TableCell>Cost Price</TableCell>
                                <TableCell>Selling Price</TableCell>
                                <TableCell>Available Stock</TableCell>
                                <TableCell>Units Sold</TableCell>
                                <TableCell>Calculated Demand Forecast</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {products.map((product) => {
                                const forecast = forecasts[product.product_id];
                                const totalDemand = forecast?.data?.reduce((acc, d) => acc + d.predicted_demand, 0);
                                return (
                                    <TableRow key={product.product_id}>
                                        <TableCell>{product.name}</TableCell>
                                        <TableCell>{product.category}</TableCell>
                                        <TableCell>${product.cost_price?.toFixed(2)}</TableCell>
                                        <TableCell>${product.selling_price?.toFixed(2)}</TableCell>
                                        <TableCell>{product.stock_available}</TableCell>
                                        <TableCell>{product.units_sold}</TableCell>
                                        <TableCell>{totalDemand ? totalDemand.toLocaleString() : 'N/A'}</TableCell>
                                    </TableRow>
                                );
                            })}
                        </TableBody>
                    </Table>
                </TableContainer>
            </DialogContent>
        </Dialog>
    );
};

export default DemandForecastModal;
