import React, { useState, useEffect } from 'react';
import {
    Dialog, DialogTitle, DialogContent, DialogActions,
    Button, TextField, Box, Typography, IconButton
} from '@mui/material';
import { useDispatch } from 'react-redux';
import { saveProduct } from '../../store/slices/productSlice';
import CloseIcon from '@mui/icons-material/Close';

const CustomTextField = ({ label, name, value, onChange, ...props }) => (
    <Box sx={{ flexGrow: 1, display: 'flex', flexDirection: 'column' }}>
        <Typography variant="body1" sx={{ mb: 1, fontWeight: 'bold' }}>
            {label}
        </Typography>
        <TextField
            name={name}
            value={value}
            onChange={onChange}
            fullWidth
            variant="outlined"
            placeholder={props.placeholder}
            sx={{
                '& .MuiOutlinedInput-root': {
                    backgroundColor: '#5a5a5a',
                    borderRadius: '12px',
                    '& fieldset': { borderColor: 'transparent' },
                    '&:hover fieldset': { borderColor: 'grey.700' },
                    '&.Mui-focused fieldset': { borderColor: 'primary.main' },
                },
                '& .MuiInputBase-input::placeholder': {
                    color: '#9e9e9e',
                },
                '& .MuiInputBase-input': {
                    color: 'white',
                }
            }}
            {...props}
        />
    </Box>
);

const ProductEditModal = ({ open, onClose, product }) => {
    const dispatch = useDispatch();
    const [formData, setFormData] = useState({
        name: '', description: '', cost_price: '', selling_price: '',
        category: '', stock_available: '', units_sold: '', customer_rating: 0,
    });

    useEffect(() => {
        if (product) {
            setFormData({
                product_id: product.product_id, name: product.name || '', description: product.description || '',
                cost_price: product.cost_price || '', selling_price: product.selling_price || '',
                category: product.category || '', stock_available: product.stock_available || '',
                units_sold: product.units_sold || '',
                customer_rating: product.customer_rating || 0,
            });
        } else {
            setFormData({
                name: '', description: '', cost_price: '', selling_price: '',
                category: '', stock_available: '', units_sold: '', customer_rating: 0,
            });
        }
    }, [product, open]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSave = () => {
        dispatch(saveProduct(formData));
        onClose();
    };

    return (
        <Dialog 
            open={open} 
            onClose={onClose} 
            fullWidth 
            maxWidth="md"
            PaperProps={{ 
                sx: { 
                    bgcolor: '#484848',
                    color: 'white', 
                    borderRadius: '16px' 
                } 
            }}
        >
            <DialogTitle sx={{ color: 'primary.main', fontWeight: 'bold', fontSize: '1.75rem', pb: 1 }}>
                {product ? 'Edit Product' : 'Add New Products'}
                <IconButton onClick={onClose} sx={{ position: 'absolute', right: 16, top: 16, color: 'primary.main' }}>
                    <CloseIcon />
                </IconButton>
            </DialogTitle>
            <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: '16px !important' }}>
                <CustomTextField name="name" label="Product Name :" placeholder="Enter Product Name" value={formData.name} onChange={handleChange} />
                <CustomTextField name="category" label="Product Category :" placeholder="Enter Product Category" value={formData.category} onChange={handleChange} />
                <Box sx={{ display: 'flex', gap: 3 }}>
                    <CustomTextField name="cost_price" label="Cost Price :" placeholder="XX,XXX,XXX" type="number" value={formData.cost_price} onChange={handleChange} />
                    <CustomTextField name="selling_price" label="Selling Price :" placeholder="XX,XXX,XXX" type="number" value={formData.selling_price} onChange={handleChange} />
                </Box>
                <CustomTextField name="description" label="Description :" placeholder="Enter Description" value={formData.description} onChange={handleChange} multiline rows={4} />
                <Box sx={{ display: 'flex', gap: 3 }}>
                    <CustomTextField name="stock_available" label="Available Stock :" placeholder="XX,XXX,XXX" type="number" value={formData.stock_available} onChange={handleChange} />
                    <CustomTextField name="units_sold" label="Units Sold :" placeholder="XX,XXX,XXX" type="number" value={formData.units_sold} onChange={handleChange} />
                </Box>
                <CustomTextField name="customer_rating" label="Customer Rating :" placeholder="e.g., 4.5" type="number" value={formData.customer_rating} onChange={handleChange} />
            </DialogContent>
            <DialogActions sx={{ p: 3, justifyContent: 'flex-end' }}>
                <Button 
                    onClick={onClose} 
                    variant="outlined" 
                    sx={{ 
                        borderColor: 'primary.main', color: 'primary.main', borderRadius: '12px',
                        textTransform: 'none', fontWeight: 'bold', px: 4, py: 1, mr: 2
                    }}
                >
                    Cancel
                </Button>
                <Button 
                    onClick={handleSave} 
                    variant="contained" 
                    color="primary"
                    sx={{ 
                        borderRadius: '12px', textTransform: 'none',
                        fontWeight: 'bold', px: 4, py: 1,
                    }}
                >
                    {product ? 'Save' : 'Add'}
                </Button>
            </DialogActions>
        </Dialog>
    );
};

export default ProductEditModal;