import React from 'react';
import {
    Dialog, DialogTitle, DialogContent, Typography, Box, Grid, Divider, IconButton
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';

const DetailItem = ({ title, value }) => (
    <Grid item xs={12} sm={6}>
        <Typography variant="subtitle2" color="text.secondary">{title}</Typography>
        <Typography variant="body1">{value}</Typography>
    </Grid>
);

const ProductViewModal = ({ open, onClose, product }) => {
    if (!product) return null;

    return (
        <Dialog open={open} onClose={onClose} fullWidth maxWidth="md">
            <DialogTitle>
                {product.name}
                <IconButton onClick={onClose} sx={{ position: 'absolute', right: 8, top: 8 }}>
                    <CloseIcon />
                </IconButton>
            </DialogTitle>
            <DialogContent dividers>
                <Typography variant="h6" gutterBottom>Product Details</Typography>
                <Grid container spacing={2}>
                    <DetailItem title="Product ID" value={product.product_id} />
                    <DetailItem title="Category" value={product.category} />
                    <DetailItem title="Cost Price" value={`$${product.cost_price?.toFixed(2)}`} />
                    <DetailItem title="Selling Price" value={`$${product.selling_price?.toFixed(2)}`} />
                    <DetailItem title="Available Stock" value={product.stock_available?.toLocaleString()} />
                    <DetailItem title="Units Sold" value={product.units_sold?.toLocaleString()} />
                    <DetailItem title="Customer Rating" value={product.customer_rating ? `${product.customer_rating} / 5` : 'N/A'} />
                </Grid>
                <Divider sx={{ my: 2 }} />
                <Box>
                    <Typography variant="subtitle2" color="text.secondary">Description</Typography>
                    <Typography variant="body1">{product.description}</Typography>
                </Box>
            </DialogContent>
        </Dialog>
    );
};

export default ProductViewModal;
