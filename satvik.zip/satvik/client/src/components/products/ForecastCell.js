import React from 'react';
import { useSelector } from 'react-redux';
import { CircularProgress } from '@mui/material';

const ForecastCell = ({ productId }) => {
    const forecast = useSelector(state => state.products.forecasts[productId]);

    if (!forecast || forecast.status === 'loading') {
        return <CircularProgress size={20} />;
    }
    if (forecast.status === 'succeeded') {
        const totalDemand = forecast.data.reduce((acc, d) => acc + d.predicted_demand, 0);
        return totalDemand.toLocaleString();
    }
    return 'N/A';
};

export default ForecastCell;
