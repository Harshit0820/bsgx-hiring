import React from 'react';
import { Card, CardContent, Typography, IconButton, Box } from '@mui/material';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import { useNavigate } from 'react-router-dom';

const ActionCard = ({ icon, title, description, to }) => {
    const navigate = useNavigate();

    return (
        <Card 
            onClick={() => navigate(to)}
            sx={{
                width: 320, // Use a fixed width for consistency
                height: '100%', // --- KEY CHANGE 1: Make card fill the height of its grid cell ---
                textAlign: 'left',
                bgcolor: 'background.paper',
                boxShadow: 3,
                borderRadius: 2,
                cursor: 'pointer',
                transition: 'transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out',
                '&:hover': {
                    transform: 'translateY(-5px)',
                    boxShadow: 6,
                },
                // --- KEY CHANGE 2: Make the Card itself a flex container ---
                display: 'flex', 
                flexDirection: 'column'
            }}
        >
            <CardContent sx={{ 
                p: 3, 
                // --- KEY CHANGE 3: Make the CardContent a flex container that grows ---
                display: 'flex', 
                flexDirection: 'column', 
                flexGrow: 1 
            }}>
                <Box sx={{ mb: 2 }}>
                    {icon}
                </Box>
                
                <Typography variant="h5" component="div" sx={{ fontWeight: 'bold' }}>
                    {title}
                </Typography>
                
                <Typography sx={{ 
                    mt: 1.5, 
                    color: 'text.secondary', 
                    // --- KEY CHANGE 4: Allow the description to grow and push the arrow down ---
                    flexGrow: 1 
                }}>
                    {description}
                </Typography>
                
                <Box sx={{ mt: 2, display: 'flex', justifyContent: 'flex-start' }}>
                    <IconButton 
                        aria-label={`go to ${title}`} 
                        sx={{ 
                            border: '1px solid', 
                            borderColor: 'text.secondary',
                            color: 'text.primary'
                        }}
                    >
                        <ArrowForwardIcon />
                    </IconButton>
                </Box>
            </CardContent>
        </Card>
    );
};

export default ActionCard;